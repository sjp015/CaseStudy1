﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbEmpSystem;Integrated security=false;uid=sa;pwd=System123");

        //SqlCommand cmd1 = new SqlCommand("SELECT * from tblEmployee");


        //cmd1.Connection = con;
        //con.Open();

        //SqlDataAdapter da = new SqlDataAdapter(cmd1);

        //DataSet ds = new DataSet();
        //da.Fill(ds);

        ////bind data to grid view control

        //GridView1.DataSource = ds;
        //GridView1.DataBind();​
    }
}