﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

public partial class Default4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (GridView1.Rows.Count >= 0)
        {

            int id = Convert.ToInt32(Request.QueryString["id"]);
            if (id == 1)
            {
                char ch = '-';
                string city, loc, rent;
                int renthi, rentlo, index, bhk;
                city = Request.QueryString["city"];
                loc = Request.QueryString["locality"];
                rent = Request.QueryString["rent"];
                index = rent.IndexOf(ch);
                rentlo = Convert.ToInt32(rent.Substring(0, index));
                renthi = Convert.ToInt32(rent.Substring(index + 1, rent.Length - index - 1));
                bhk = Convert.ToInt32(Request.QueryString["BHK"]);
                SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated security=false;uid=sa;pwd=System123");
                SqlCommand cmd = new SqlCommand("select vHouseNo,iRentAmt,iBhk,cCity,cLocality,dAvailable_from from tblHouse where iBhk=@bhk and iRentAmt>=@lo and iRentAmt<@hi and vUserId_Broker!=@brok");
                cmd.Parameters.Add("@bhk", bhk);
                cmd.Parameters.Add("@lo", rentlo);
                cmd.Parameters.Add("@hi", renthi);
                cmd.Parameters.Add("@brok", "NOT ASSIGNED");
                //SqlCommand cmd = new SqlCommand("Select * from tblHouse");
                cmd.Connection = con;
                con.Open();

                SqlDataAdapter da = new SqlDataAdapter(cmd);

                DataSet ds = new DataSet();
                da.Fill(ds);

                //bind data to grid view control

                GridView1.DataSource = ds;
                GridView1.DataBind();
                con.Close();
            }
            else if (id == 2)
            {
                char ch = '-';
                string city, loc, rent,food;
                int renthi, rentlo, index, bhk;
                city = Request.QueryString["city"];
                loc = Request.QueryString["locality"];
                food = Request.QueryString["food"];
                rent = Request.QueryString["rent"];
                index = rent.IndexOf(ch);
                rentlo = Convert.ToInt32(rent.Substring(0, index));
                renthi = Convert.ToInt32(rent.Substring(index + 1, rent.Length - index - 1));
                bhk = Convert.ToInt32(Request.QueryString["BHK"]);
                SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated security=false;uid=sa;pwd=System123");
                SqlCommand cmd = new SqlCommand("select vRoomNo,iRentAmt,iBhk,iFloor,cFoodFacility,cCity,cLocality,dAvailable_from from tblPg where iBhk=@bhk and iRentAmt>=@lo and iRentAmt<@hi and cFoodFacility=@foodfac and vUserId_Broker!=@brok");
                cmd.Parameters.Add("@bhk", bhk);
                cmd.Parameters.Add("@lo", rentlo);
                cmd.Parameters.Add("@hi", renthi);
                cmd.Parameters.Add("@foodfac", food);
                cmd.Parameters.Add("@brok", "NOT ASSIGNED");
                //SqlCommand cmd = new SqlCommand("Select * from tblHouse");
                cmd.Connection = con;
                con.Open();

                SqlDataAdapter da = new SqlDataAdapter(cmd);

                DataSet ds = new DataSet();
                da.Fill(ds);

                //bind data to grid view control

                GridView1.DataSource = ds;
                GridView1.DataBind();
                con.Close();
            }
            else
            {
                char ch = '-';
                string city, loc, rent;
                int renthi, rentlo, index, bhk;
                city = Request.QueryString["city"];
                loc = Request.QueryString["locality"];
                rent = Request.QueryString["rent"];
                index = rent.IndexOf(ch);
                rentlo = Convert.ToInt32(rent.Substring(0, index));
                renthi = Convert.ToInt32(rent.Substring(index + 1, rent.Length - index - 1));
                bhk = Convert.ToInt32(Request.QueryString["BHK"]);
                SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated security=false;uid=sa;pwd=System123");
                SqlCommand cmd = new SqlCommand("select vFlatNo,iRentAmt,iBhk,iFloor,cCity,cLocality,dAvailable_from from tblFlat where iBhk=@bhk and iRentAmt>=@lo and iRentAmt<=@hi and vUserId_Broker!=@brok");
                cmd.Parameters.Add("@bhk", bhk);
                cmd.Parameters.Add("@lo", rentlo);
                cmd.Parameters.Add("@hi", renthi);
                cmd.Parameters.Add("@brok", "NOT ASSIGNED");
                //SqlCommand cmd = new SqlCommand("Select * from tblHouse");
                cmd.Connection = con;
                con.Open();

                SqlDataAdapter da = new SqlDataAdapter(cmd);

                DataSet ds = new DataSet();
                da.Fill(ds);

                //bind data to grid view control

                GridView1.DataSource = ds;
                GridView1.DataBind();
                con.Close();
            }
        }
        else
        {
            MessageBox.Show("We couldn't Find Any House for You!!");
        }
       
        //MessageBox.Show(city+" "+loc+" "+rentlo+" "+" "+renthi+" "+bhk+" "+id);
    }



    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;

        // Display the first name from the selected row.
        // In this example, the third column (index 2) contains
        // the first name.
        MessageLabel.Text = "You selected " + row.Cells[2].Text + ".";
    }
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated security=false;uid=sa;pwd=System123");
        try
        {
            string OwnerId,BrokerId;
            string clientid = Request.QueryString["uid"];
            int id = Convert.ToInt32(Request.QueryString["id"]);
            GridViewRow r = GridView1.Rows[e.NewSelectedIndex];
            SqlDataAdapter da = new SqlDataAdapter();
            string name = r.Cells[1].Text;
            int rentamt = Convert.ToInt32(r.Cells[2].Text);
            if (id == 1)
            {
                SqlCommand cmd = new SqlCommand("select @Bid=vUserId_Broker,@Oid=vUserId_Owner from tblHouse where vHouseNo=@houseid");
                cmd.Parameters.Add("@houseid", name);
                cmd.Parameters.Add("@Bid", SqlDbType.Char, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@Oid", SqlDbType.Char, 20).Direction = ParameterDirection.Output;
                cmd.Connection = con;
                con.Open();
                da.SelectCommand = cmd;
                da.SelectCommand.ExecuteNonQuery();
                BrokerId = cmd.Parameters["@Bid"].Value.ToString();
                OwnerId = cmd.Parameters["@Oid"].Value.ToString();
                con.Close();
            }
            else if(id==2)
            {
                SqlCommand cmd = new SqlCommand("select @Bid=vUserId_Broker,@Oid=vUserId_Owner from tblPg where vRoomNo=@roomid");
                cmd.Parameters.Add("@roomid", name);
                cmd.Parameters.Add("@Bid", SqlDbType.Char, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@Oid", SqlDbType.Char, 20).Direction = ParameterDirection.Output;
                cmd.Connection = con;
                con.Open();
                da.SelectCommand = cmd;
                da.SelectCommand.ExecuteNonQuery();
                BrokerId = cmd.Parameters["@Bid"].Value.ToString();
                OwnerId = cmd.Parameters["@Oid"].Value.ToString();
                con.Close();
            }
            else
            {
                SqlCommand cmd = new SqlCommand("select @Bid=vUserId_Broker,@Oid=vUserId_Owner from tblFlat where vFlatNo=@flatid");
                cmd.Parameters.Add("@flatid", name);
                cmd.Parameters.Add("@Bid", SqlDbType.Char, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@Oid", SqlDbType.Char, 20).Direction = ParameterDirection.Output;
                cmd.Connection = con;
                con.Open();
                da.SelectCommand = cmd;
                da.SelectCommand.ExecuteNonQuery();
                BrokerId = cmd.Parameters["@Bid"].Value.ToString();
                OwnerId = cmd.Parameters["@Oid"].Value.ToString();
                con.Close();
            }
            SqlCommand cmd1 = new SqlCommand("Insert into tblRequest (iType,propertyid,vClientId,vBrokerId,vOwnerId,iRentAmt) values(@id,@propid,@clientid,@brokerid,@ownerid,@rent)");
            cmd1.Parameters.Add("@id", id);
            cmd1.Parameters.Add("@propid", name);
            cmd1.Parameters.Add("@clientid", clientid);
            cmd1.Parameters.Add("@brokerid", BrokerId);
            cmd1.Parameters.Add("@ownerid", OwnerId);
            cmd1.Parameters.Add("@rent", rentamt);
            cmd1.Connection = con;
            con.Open();
            da.InsertCommand = cmd1;
            da.InsertCommand.ExecuteNonQuery();
            con.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Already Requested");
            string m = "Already Requested!";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
            con.Close();
        }

    }
}