﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Tab1_Click(object sender, EventArgs e)
    {
        Tab1.CssClass = "Clicked";
        Tab2.CssClass = "Initial";
        Tab3.CssClass = "Initial";
        MainView.ActiveViewIndex = 0;
    }
    protected void Tab2_Click(object sender, EventArgs e)
    {
        Tab1.CssClass = "Initial";
        Tab2.CssClass = "Clicked";
        Tab3.CssClass = "Initial";
        MainView.ActiveViewIndex = 1;
    }
    protected void Tab3_Click(object sender, EventArgs e)
    {
        Tab1.CssClass = "Initial";
        Tab2.CssClass = "Initial";
        Tab3.CssClass = "Clicked";
        MainView.ActiveViewIndex = 2;
        //cmd.parameters.add("@ad",ddlname.value Or ddlname.text)
    }

    protected void btnHsSearch_Click(object sender, EventArgs e)
    {
        string userid = Request.QueryString["uid"];
//        dlist.Text.Substring(0,5)
        Response.Redirect("frmClientSearch.aspx?city=" + txtHsCity.Text+"&locality="+txtHsLocality.Text+"&Rent="+ddHsRent.Text+"&BHK="+ddHsBHK.SelectedValue+"&id="+1+"&uid="+userid);
    }
    protected void btnPgSearch_Click(object sender, EventArgs e)
    {
        string userid = Request.QueryString["uid"];
        //        dlist.Text.Substring(0,5)
        Response.Redirect("frmClientSearch.aspx?city=" + txtPgCity.Text + "&locality=" + txtPgLocality.Text + "&Rent=" + ddPgRent.Text + "&BHK=" + ddPgBHK.SelectedValue +"&food="+rblPgFood.Text+ "&id=" + 2 + "&uid=" + userid);
    }
    protected void btnFlatSearch_Click(object sender, EventArgs e)
    {
        string userid = Request.QueryString["uid"];
        //        dlist.Text.Substring(0,5)
        Response.Redirect("frmClientSearch.aspx?city=" + txtFlatCity.Text + "&locality=" + txtFlatLocality.Text + "&Rent=" + ddFlatRent.Text + "&BHK=" + ddFlatBHK.SelectedValue + "&id=" + 3 + "&uid=" + userid);
    }
}