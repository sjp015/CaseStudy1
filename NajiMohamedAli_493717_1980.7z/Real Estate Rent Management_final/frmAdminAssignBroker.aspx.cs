﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DropDownList1.Items.Insert(0, new ListItem("-Select-", "0"));
        DropDownList2.Items.Insert(0, new ListItem("-Select-", "0"));
    }
    protected void Tab1_Click(object sender, EventArgs e)
    {
        Tab1.CssClass = "Clicked";
        Tab2.CssClass = "Initial";
        Tab3.CssClass = "Initial";
        MainView.ActiveViewIndex = 0;
    }
    protected void Tab2_Click(object sender, EventArgs e)
    {
        Tab1.CssClass = "Initial";
        Tab2.CssClass = "Clicked";
        Tab3.CssClass = "Initial";
        MainView.ActiveViewIndex = 1;
    }
    protected void Tab3_Click(object sender, EventArgs e)
    {
        Tab1.CssClass = "Initial";
        Tab2.CssClass = "Initial";
        Tab3.CssClass = "Clicked";
        MainView.ActiveViewIndex = 2;
        //cmd.parameters.add("@ad",ddlname.value Or ddlname.text)
    }
    protected void btnHsAssign_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated security=false;uid=sa;pwd=System123");
        SqlCommand cmd = new SqlCommand("Update tblHouse set vUserId_Broker=@broker where vHouseNo=@HNo");
        cmd.Connection = con;
        cmd.Parameters.Add("@broker", DropDownList2.Text);
        cmd.Parameters.Add("@HNo", DropDownList1.Text);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        Server.TransferRequest(Request.Url.AbsolutePath, false);
    }


    protected void btnPgAssign_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated security=false;uid=sa;pwd=System123");
        SqlCommand cmd = new SqlCommand("Update tblPg set vUserId_Broker=@broker where vRoomNo=@HNo");
        cmd.Connection = con;
        cmd.Parameters.Add("@broker", DropDownList4.Text);
        cmd.Parameters.Add("@HNo", DropDownList3.Text);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        Server.TransferRequest(Request.Url.AbsolutePath, false);
    }
    protected void btnFlatAssign_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated security=false;uid=sa;pwd=System123");
        SqlCommand cmd = new SqlCommand("Update tblFlat set vUserId_Broker=@broker where vFlatNo=@HNo");
        cmd.Connection = con;
        cmd.Parameters.Add("@broker", DropDownList6.Text);
        cmd.Parameters.Add("@HNo", DropDownList5.Text);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        Server.TransferRequest(Request.Url.AbsolutePath, false);
    }
}