﻿ function validate() {
           var name = document.getElementById('<%=txtOwnerName.ClientID %>').value;
           var phnNo = document.getElementById('<%=txtOwnerPhn.ClientID %>').value;
           var Email = document.getElementById('<%=txtOwnerEmail.ClientID %>').value;
           if (name == "") {
               alert("Enter Name");
               return false;
           }
           if (phnNo == "") {
               alert("Enter Phone Number");
               return false;
           }
           if (Email == "") {
               alert("Enter Email");
               return false;
           }
           var emailPat = /^(\".*\"|[A-Za-z]\w*)@(\[\d{1,3}(\.\d{1,3}){3}]|[A-Za-z]\w*(\.[A-Za-z]\w*)+)$/
           var EmailmatchArray = Email.match(emailPat);
           if (EmailmatchArray == null) {
               alert("Your email address seems incorrect. Please try again.");
               return false;
           }
       }
        
        