﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnPasswordChange_Click(object sender, EventArgs e)
    {
         SqlConnection connection = new SqlConnection(@"Server=INBASDPC12695;Database=dbRentManagmt;Integrated Security=false;uid=sa;pwd=System123");
        connection.Open();
        SqlCommand cmd = new SqlCommand("SELECT * FROM tblAdmin WHERE vUserid=@uid AND vPassword=@currentpass", connection);
        cmd.Parameters.AddWithValue("@uid", Session["adk"]);
        cmd.Parameters.AddWithValue("@currentpass", txtACurrentPass.Text);

        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            dr.Close();
            SqlCommand changepass = new SqlCommand("prcAdminChangePass", connection);
            changepass.CommandType = CommandType.StoredProcedure;
            changepass.Parameters.AddWithValue("@uid", Session["adk"]);
            changepass.Parameters.AddWithValue("@newpass", txtANewPass.Text);
            
            changepass.ExecuteNonQuery();
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Password Changed')</script>");
            //emptystring();
        }
        else
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Current Password')</script>");
            //emptystring();
        }

    }
    protected void txtACurrentPass_TextChanged(object sender, EventArgs e)
    {

    }
    }
