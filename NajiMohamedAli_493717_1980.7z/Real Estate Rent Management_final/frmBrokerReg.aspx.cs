﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using Generation;
using System.Threading;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnBrokerSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string username, password, link;
            link = "frmBrokerLogin.aspx";
            username = Generate.GetRandomAlphanumericStringUser(5);
            password = Generate.GetRandomAlphanumericString(8);
            SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated Security=false;uid=sa;pwd=System123");
            con.Open();
            SqlCommand cmd = new SqlCommand("prcInsertBroker", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@name", txtBrokerName.Text);
            cmd.Parameters.Add("@phone", txtBrokerPhn.Text);
            cmd.Parameters.Add("@city", txtCity.Text);
            cmd.Parameters.Add("@locality", txtLocality.Text);
            cmd.Parameters.Add("@email", txtBrokerEmail.Text);
            cmd.Parameters.Add("@userid", username);
            cmd.Parameters.Add("@pwd", password);
            cmd.ExecuteNonQuery();
            Response.Redirect("frmPostReg.aspx?uname=" + username + "&pwd=" + password + "&link=" + link);
        }
        catch (ThreadAbortException ex)
        {


        }
        catch (Exception ex)
        {
            string m = "Mobile Number Already Exists";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
        }
    }
}