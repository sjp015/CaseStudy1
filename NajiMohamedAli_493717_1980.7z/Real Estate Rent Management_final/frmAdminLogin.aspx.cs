﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnAdminlogin_Click(object sender, EventArgs e)
    {
        string namedis;
        int i = 0;
        bool flag = false;
        SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        SqlCommand cmd = new SqlCommand("select vName,vUserid from tblAdmin where vUserid=@user and vPassword=@pwd", con);
        cmd.Parameters.Add("@user", txtadminUser.Text);
        cmd.Parameters.Add("@pwd", txtadminPassword.Text);
        //cmd.Parameters.Add("@name", SqlDbType.Char, 50).Direction = ParameterDirection.Output;
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds, "tblAdmin");
        DataTable dt = ds.Tables["tblAdmin"];
        da.SelectCommand.ExecuteNonQuery();
        if (dt.Rows.Count > 0)
        {
            Session["adk"] = dt.Rows[0][0];
            Response.Redirect("frmAdminHome.aspx?name=" + dt.Rows[0][0].ToString() + "&uid=" + dt.Rows[0][1]);
        }
        else
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
        }​​
    }
}