﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System.Threading;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string userid = Request.QueryString["uid"];
        SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated security=false;uid=sa;pwd=System123");

        SqlCommand cmd1 = new SqlCommand("SELECT * from tblRequest where vBrokerId=@Bid");
        cmd1.Parameters.Add("@Bid", userid);
        cmd1.Connection = con;
        con.Open();

        SqlDataAdapter da = new SqlDataAdapter(cmd1);

        DataSet ds = new DataSet();
        da.Fill(ds);

        //bind data to grid view control

        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;

        // Display the first name from the selected row.
        // In this example, the third column (index 2) contains
        // the first name.
        MessageLabel.Text = "You selected " + row.Cells[2].Text + ".";

    }
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated security=false;uid=sa;pwd=System123");
        try
        {
            GridViewRow r = GridView1.Rows[e.NewSelectedIndex];
            int type = Convert.ToInt32(r.Cells[1].Text);
            string propid = r.Cells[2].Text;
            string ClientId = r.Cells[3].Text;
            string BrokerId = r.Cells[4].Text;
            string OwnerId = r.Cells[5].Text;
            int rentamt = Convert.ToInt32(r.Cells[8].Text);
            SqlDataAdapter da = new SqlDataAdapter();
            //int empId = Convert.ToInt32(r.Cells[2].Text);
            //int salary = Convert.ToInt32(r.Cells[3].Text);
            //        MessageBox.Show(name + " " + empId + " " + salary);
            SqlCommand cmd1 = new SqlCommand("Insert into tblToOwnerRequest (iType,propertyid,vClientId,vBrokerId,vOwnerId,iRentAmt) values(@id,@propid,@clientid,@brokerid,@ownerid,@rentamt)");
            cmd1.Parameters.Add("@id", type);
            cmd1.Parameters.Add("@propid", propid);
            cmd1.Parameters.Add("@clientid", ClientId);
            cmd1.Parameters.Add("@brokerid", BrokerId);
            cmd1.Parameters.Add("@ownerid", OwnerId);
            cmd1.Parameters.Add("@rentamt", rentamt);
            cmd1.Connection = con;
            con.Open();
            da.InsertCommand = cmd1;
            da.InsertCommand.ExecuteNonQuery();
            con.Close();
            SqlCommand cmd2 = new SqlCommand("Update tblRequest set Status=@stat where propertyid=@propid and vClientId=@clientid");
            cmd2.Parameters.Add("@stat", "Forwarded");
            cmd2.Parameters.Add("@propid", propid);
            cmd2.Parameters.Add("@clientid", ClientId);
            cmd2.Connection = con;
            con.Open();
            da.UpdateCommand = cmd2;
            da.UpdateCommand.ExecuteNonQuery();
            con.Close();
            Server.TransferRequest(Request.Url.AbsolutePath, false);
        }
        catch (Exception ex)
        {
            string m = "Request Has Already been Forwarded";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
            con.Close();
        }
    }
}