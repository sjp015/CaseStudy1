﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage5 : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adk"] == null)
        {
            Server.Transfer("frmHomePage.aspx");
        }
        string userid = Request.QueryString["uid"];
        hypShowReq.NavigateUrl = "frmBrokerShowReqs.aspx?uid=" + userid;
        hypcomm.NavigateUrl = "frmBrokerShowComm.aspx?user=" + userid;
    }
}
