﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

public partial class Default4 : System.Web.UI.Page
{
    public static string propid;
    public static string ClientId, BrokerId;
    public static string statcheck;
    public static int type, rentamt;
    protected void Page_Load(object sender, EventArgs e)
    {
        string userid = Request.QueryString["uid"];
        SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated security=false;uid=sa;pwd=System123");

        SqlCommand cmd1 = new SqlCommand("SELECT * from tblToOwnerRequest where vApproval_Status=@stat");
        cmd1.Parameters.Add("@stat", "Pending");
        cmd1.Connection = con;
        con.Open();

        SqlDataAdapter da = new SqlDataAdapter(cmd1);

        DataSet ds = new DataSet();
        da.Fill(ds);

        //bind data to grid view control

        GridView2.DataSource = ds;
        GridView2.DataBind();
    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView2.SelectedRow;

        // Display the first name from the selected row.
        // In this example, the third column (index 2) contains
        // the first name.
        MessageLabel.Text = "You selected " + row.Cells[2].Text + ".";
    }
    protected void GridView2_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

        try
        {
            GridViewRow r = GridView2.Rows[e.NewSelectedIndex];
            type = Convert.ToInt32(r.Cells[1].Text);
            propid = r.Cells[2].Text;
            ClientId = r.Cells[3].Text;
            BrokerId = r.Cells[4].Text;
            statcheck = r.Cells[6].Text;
            rentamt = Convert.ToInt32(r.Cells[7].Text);
            //string BrokerId = r.Cells[4].Text;
            //string OwnerId = r.Cells[5].Text;
            //SqlDataAdapter da = new SqlDataAdapter();
            //int empId = Convert.ToInt32(r.Cells[2].Text);
            //int salary = Convert.ToInt32(r.Cells[3].Text);
            //        MessageBox.Show(name + " " + empId + " " + salary);
            //SqlCommand cmd1 = new SqlCommand("Insert into tblToOwnerRequest (iType,propertyid,vClientId,vBrokerId,vOwnerId) values(@id,@propid,@clientid,@brokerid,@ownerid)");
            //cmd1.Parameters.Add("@id", type);
            //cmd1.Parameters.Add("@propid", propid);
            //cmd1.Parameters.Add("@clientid", ClientId);
            //cmd1.Parameters.Add("@brokerid", BrokerId);
            //cmd1.Parameters.Add("@ownerid", OwnerId);
            //cmd1.Connection = con;
            //con.Open();
            //da.InsertCommand = cmd1;
            //da.InsertCommand.ExecuteNonQuery();
            //con.Close();
            //SqlCommand cmd2 = new SqlCommand("Update tblRequest set Status=@stat where propertyid=@propid and vClientId=@clientid");
            //cmd2.Parameters.Add("@stat", "Forwarded");
            //cmd2.Parameters.Add("@propid", propid);
            //cmd2.Parameters.Add("@clientid", ClientId);
            //cmd2.Connection = con;
            //con.Open();
            //da.UpdateCommand = cmd2;
            //da.UpdateCommand.ExecuteNonQuery();
            //con.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString());

        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (statcheck == "Pending")
        {

            string stat;
            SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated security=false;uid=sa;pwd=System123");
            SqlCommand cmd = new SqlCommand("prcStatusToOwnerReq");
            cmd.CommandType = CommandType.StoredProcedure;
            stat = ddList.SelectedValue.ToString();
            cmd.Parameters.Add("@stat", stat);
            cmd.Parameters.Add("@propid", propid);
            cmd.Parameters.Add("@clientid", ClientId);
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            if (stat == "Approved")
            {
                SqlCommand cmd2 = new SqlCommand("prcToBrokerSales");
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.Add("@type", type);
                cmd2.Parameters.Add("@propid", propid);
                cmd2.Parameters.Add("@comm", rentamt);
                cmd2.Parameters.Add("@user", BrokerId);
                cmd2.Connection = con;
                con.Open();
                cmd2.ExecuteNonQuery();
                con.Close();
                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandType = CommandType.StoredProcedure;
                cmd1.Connection = con;
                con.Open();
                switch (type)
                {
                    case 1: cmd1.CommandText = "prcHouseStatUpdate";
                        cmd1.Parameters.Add("@stat", "Not Available");
                        cmd1.Parameters.Add("@houseid", propid);
                        cmd1.ExecuteNonQuery();
                        con.Close();
                        break;
                    case 2: cmd1.CommandText = "prcPgStatUpdate";
                        cmd1.Parameters.Add("@stat", "Not Available");
                        cmd1.Parameters.Add("@houseid", propid);
                        cmd1.ExecuteNonQuery();
                        con.Close();
                        break;
                    case 3: cmd1.CommandText = "prcFlatStatUpdate";
                        cmd1.Parameters.Add("@stat", "Not Available");
                        cmd1.Parameters.Add("@houseid", propid);
                        cmd1.ExecuteNonQuery();
                        con.Close();
                        break;
                }
            }
            Server.TransferRequest(Request.Url.AbsolutePath, false);
        }
        else
        {
            MessageBox.Show("Request Has been Approved/Denied Already!!");
        }

    }
}