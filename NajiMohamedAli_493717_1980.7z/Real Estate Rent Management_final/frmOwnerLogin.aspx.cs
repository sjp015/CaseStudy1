﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    

    }
    protected void btnOwnerlogin_Click(object sender, EventArgs e)
    {

        int i = 0,count;
        bool flag = false;
        SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        SqlCommand cmd = new SqlCommand("select vName,vUserId from tblOwner where vUserId=@user and vPassword=@pwd", con);
        SqlCommand cmd1 = new SqlCommand("select @ctr=counter from validation", con);
        cmd1.Parameters.Add("@ctr", SqlDbType.Int).Direction = ParameterDirection.Output;
        cmd1.ExecuteNonQuery();
        count=Convert.ToInt32(cmd1.Parameters["@ctr"].Value.ToString());
        cmd.Parameters.AddWithValue("@user", txtOwnerUser.Text);
        cmd.Parameters.AddWithValue("@pwd", txtOwnerPassword.Text);
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds, "tblOwner");
        DataTable dt = ds.Tables["tblOwner"];
        
            if ((dt.Rows.Count>0)&&(count<3))
            {
                Session["adk"] = dt.Rows[0][1];
                Response.Redirect("frmOwnerHome.aspx?username=" + dt.Rows[0][0]+"&uid="+dt.Rows[0][1]);
            }
            else if (count>=3)
            {
                LblAdmin.Text = "Your Account has been Blocked.Contact Admin";
                
            }​
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
            }

    }
}