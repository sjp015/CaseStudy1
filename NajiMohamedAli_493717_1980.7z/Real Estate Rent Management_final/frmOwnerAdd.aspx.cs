﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System.Threading;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Tab1_Click(object sender, EventArgs e)
    {
        Tab1.CssClass = "Clicked";
        Tab2.CssClass = "Initial";
        Tab3.CssClass = "Initial";
        MainView.ActiveViewIndex = 0;
    }
    protected void Tab2_Click(object sender, EventArgs e)
    {
        Tab2.CssClass = "Clicked";
        Tab1.CssClass = "Initial";
        Tab3.CssClass = "Initial";
        MainView.ActiveViewIndex = 1;
    }
    protected void Tab3_Click(object sender, EventArgs e)
    {
        Tab3.CssClass = "Clicked";
        Tab1.CssClass = "Initial";
        Tab2.CssClass = "Initial";
        MainView.ActiveViewIndex = 2;
    }
    protected void btnAddHouse_Click(object sender, EventArgs e)
    {
        try
        {
            string username;
            username = Request.QueryString["uid"];
            SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated Security=false;uid=sa;pwd=System123");
            con.Open();
            SqlCommand cmd = new SqlCommand("prcAddHouse", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@houseno", txtHouseNo.Text);
            cmd.Parameters.Add("@city", txtCity.Text);
            cmd.Parameters.Add("@locality", txtLocality.Text);
            cmd.Parameters.Add("@address", txtaddress.Text);
            cmd.Parameters.Add("@Rent", txtRent.Text);
            cmd.Parameters.Add("@bhk", DrpBhk.Text);
            cmd.Parameters.Add("@availability", DropDownList1.Text);
            cmd.Parameters.Add("@dateav", Calendar1.SelectedDate);
            cmd.Parameters.Add("@user", username);
            cmd.ExecuteNonQuery();
            Server.TransferRequest(Request.Url.AbsolutePath, false);
        }
        catch (ThreadAbortException ex)
        {


        }
        catch (Exception ex)
        {
            string m = "Couldn't Add details please try Again with different Property ID";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
        }
    }
    protected void btnaddPg_Click(object sender, EventArgs e)
    {
        try
        {
            string username;
            username = Request.QueryString["uid"];
            SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated Security=false;uid=sa;pwd=System123");
            con.Open();
            SqlCommand cmd = new SqlCommand("prcAddPg", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@roomno", txtPgNumber.Text);
            cmd.Parameters.Add("@city", txtPgCity.Text);
            cmd.Parameters.Add("@locality", txtPgLocality.Text);
            cmd.Parameters.Add("@address", txtPgAddress.Text);
            cmd.Parameters.Add("@Rent", txtPgRent.Text);
            cmd.Parameters.Add("@bhk", DrpPgBhk.Text);
            cmd.Parameters.Add("@floor", txtPgFloor.Text);
            cmd.Parameters.Add("@food", DrpPgFood.Text);
            cmd.Parameters.Add("@availability", DrpPgAvailability.Text);
            cmd.Parameters.Add("@dateav", Calendar2.SelectedDate);
            cmd.Parameters.Add("@user", username);
            cmd.ExecuteNonQuery();
            Server.TransferRequest(Request.Url.AbsolutePath, false);
        }
        catch (ThreadAbortException ex)
        {


        }
        catch (Exception ex)
        {
            string m = "Couldn't Add details please try Again with different Property ID";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
        }
    }
    protected void btnAddFlat_Click(object sender, EventArgs e)
    {
        try
        {
            string username;
            username = Request.QueryString["uid"];
            SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated Security=false;uid=sa;pwd=System123");
            con.Open();
            SqlCommand cmd = new SqlCommand("prcAddFlat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@flatno", txtFlatNumber.Text);
            cmd.Parameters.Add("@city", txtFlatCity.Text);
            cmd.Parameters.Add("@locality", txtFlatLocality.Text);
            cmd.Parameters.Add("@address", txtFlatAddress.Text);
            cmd.Parameters.Add("@Rent", txtFlatRent.Text);
            cmd.Parameters.Add("@bhk", DrpFlatBhk.Text);
            cmd.Parameters.Add("@floor", txtFlatFloor.Text);
            cmd.Parameters.Add("@availability", DrpFlatAvailable.Text);
            cmd.Parameters.Add("@dateav", Calendar3.SelectedDate);
            cmd.Parameters.Add("@user", username);
            cmd.ExecuteNonQuery();
            Server.TransferRequest(Request.Url.AbsolutePath, false);
        }
        catch (ThreadAbortException ex)
        {


        }
        catch (Exception ex)
        {
            string m = "Couldn't Add details please try Again with different Property ID";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
        }
    }
}