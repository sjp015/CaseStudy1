﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnBrokerlogin_Click1(object sender, EventArgs e)
    {
        string namedis;
        int i = 0;
        bool flag = false;
        SqlConnection con = new SqlConnection(@"server=INBASDPC12695;database=dbRentManagmt;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        SqlCommand cmd = new SqlCommand("select vName,vUserId from tblBroker where vUserId=@user and vPassword=@pwd", con);
        cmd.Parameters.Add("@user", txtBrokerUser.Text);
        cmd.Parameters.Add("@pwd", txtBrokePassword.Text);
        cmd.Parameters.Add("@name", SqlDbType.Char, 50).Direction = ParameterDirection.Output;
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds, "tblBroker");
        DataTable dt = ds.Tables["tblBroker"];
        da.SelectCommand.ExecuteNonQuery();
        if (dt.Rows.Count>0)
        {
            Session["adk"] = dt.Rows[0][1];
            Response.Redirect("frmBrokerHome.aspx?username=" + dt.Rows[0][0]+"&uid="+dt.Rows[0][1]);
        }
        else
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
        }​
    }
}