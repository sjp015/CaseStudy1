﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RTAProfile : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnActandRules_Click(object sender, EventArgs e)
    {
        Response.Redirect("ActandRules.aspx");
    }
    protected void btnGeneralInfo_Click(object sender, EventArgs e)
    {
        Response.Redirect("GeneralInfo.aspx");
    }
    protected void btnPollutionControl_Click(object sender, EventArgs e)
    {
        Response.Redirect("PollutionControl.aspx");
    }
    protected void btnTaxAndFees_Click(object sender, EventArgs e)
    {
        Response.Redirect("TaxAndFees.aspx");
    }
    protected void btnAnnual_Click(object sender, EventArgs e)
    {
        Response.Redirect("Annual.aspx");
    }
    protected void btnimpLinks_Click(object sender, EventArgs e)
    {
        Response.Redirect("impLinks.aspx");
    }
    protected void btnApplyOnline_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserLogin.aspx");
    }
    protected void btnCheckStatus_Click(object sender, EventArgs e)
    {
        Response.Redirect("Check Status.aspx");
    }
    protected void btnGallery_Click(object sender, EventArgs e)
    {
        Response.Redirect("GalleryMain.aspx");
    }
    protected void btnLogOut_Click(object sender, EventArgs e)
    {
        Response.Redirect("LoginOfAdminOrUser.aspx");
    }
    protected void btnUserHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("RTAprofile.aspx");
    }
}
