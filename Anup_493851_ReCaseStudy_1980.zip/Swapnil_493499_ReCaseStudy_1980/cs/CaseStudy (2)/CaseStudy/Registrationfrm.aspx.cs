﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Generation;
using System.Windows.Forms;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        if ((txtpan.Text != "") && (txtmobile.Text != "") && (txtfullname.Text != "")&&(txtemail.Text != "")&&(txtage.Text!="")&&(txtaddr.Text!=""))
        {
            string userid, password;
            userid = Generate.GetRandomAlphanumericStringUser(5);
            password = Generate.GetRandomAlphanumericStringUser(8);
            try
            {
                SqlConnection con = new SqlConnection(@"server=INBASDPC12849\SQLEXPRESS;database=dbCasestudy;Integrated security=true");
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into tblSignup values('" + txtfullname.Text + "','" + txtage.Text + "','" + RadioButtonList1.Text + "','" + txtaddr.Text + "','" + txtmobile.Text + "','" + txtemail.Text + "','" + txtpan.Text + "','" + userid + "','" + password + "')", con);


                cmd.ExecuteNonQuery();
                string m = "Signed up Successfully!!!   your User Id is  :  " + userid + "    and Password is :  " + password;
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
                txtfullname.Text = "";
                txtage.Text = "";
                RadioButtonList1.Text = "";
                txtmobile.Text = "";
                txtemail.Text = "";
                txtpan.Text = "";
                txtaddr.Text = "";
            }
            catch (Exception ex)
            {

                global::System.Windows.Forms.MessageBox.Show(ex.ToString());
            } 
        }
        else
        {
            string m = "Enter All Fields";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
        }
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtfullname.Text = "";
        txtage.Text = "";
        RadioButtonList1.Text = "";
        txtmobile.Text = "";
        txtemail.Text = "";
        txtpan.Text = "";
        txtaddr.Text = "";
        Server.Transfer("Registrationfrm.aspx");
    }
}