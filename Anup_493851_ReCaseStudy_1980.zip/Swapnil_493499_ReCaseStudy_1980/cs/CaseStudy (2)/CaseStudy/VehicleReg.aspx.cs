﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Generation;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System.Text;

public partial class Default2 : System.Web.UI.Page
{

    public static string uniq;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adk"] == null)
        {
            Response.Redirect("home.aspx");
        }
        


    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {


    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {



    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label1.Visible = true;
        Label2.Visible = true;
        Label3.Visible = true;
        Label4.Visible = true;
        TextBox2.Visible = true;
        TextBox1.Visible = true;
        TextBox3.Visible = true;
        TextBox4.Visible = true;
        btnCheck.Visible = true;
        lblCheck.Visible = true;
        btnFancySelect.Visible=true;
       
        //TextBox2.Text = DropDownList2.Text.Substring(0, 2);

    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtbody.Text = " ";
        txtcc.Text = " ";
        txtcolor.Text = " ";
        txtcyclinder.Text = " ";
        txtlicence.Text = " ";
        txtengno.Text = "";
        txtmfgdate.Text = "";
        txtmodel.Text = "";
        txtseating.Text = "";
        txtwgt.Text = "";
        DropDownList1.Text = "";
        DropDownList2.Text = "";
        Server.Transfer("VehicleReg.aspx");


    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        if ((txtbody.Text != "") && (txtcc.Text != "") && (txtcolor.Text != "") && (txtcyclinder.Text != "") && (txtengno.Text != "") && (txtlicence.Text != "") && (txtmfgdate.Text != "") && (txtmodel.Text != "") && (txtseating.Text != "") && (txtwgt.Text != "") && (DropDownList1.Text != "--Select--") && (DropDownList2.Text != "--Select--"))
        {
            string user = Session["adk"].ToString();
            uniq = Generate.GetRandomAlphanumericStringUser(6);
           
            string uniq1 = "hai";
            if (uniq != null)
            {
                try
                {
                    SqlConnection con = new SqlConnection(@"server=INBASDPC12849\SQLEXPRESS;database=dbCasestudy;Integrated security=true");
                    SqlCommand cmd = new SqlCommand("InsertIntoApplicantList2");
                    
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();


                    cmd.Parameters.AddWithValue("@engno", txtengno.Text);
                    cmd.Parameters.AddWithValue("@color", txtcolor.Text);
                    cmd.Parameters.AddWithValue("@model", txtmodel.Text);
                    cmd.Parameters.AddWithValue("@body", txtbody.Text);
                    cmd.Parameters.AddWithValue("@mfgdate", txtmfgdate.Text);
                    cmd.Parameters.AddWithValue("@fuel", DropDownList1.Text);
                    cmd.Parameters.AddWithValue("@numofcyl", txtcyclinder.Text);
                    cmd.Parameters.AddWithValue("@unladenwgt", txtwgt.Text);
                    cmd.Parameters.AddWithValue("@seating", txtseating.Text);
                    cmd.Parameters.AddWithValue("@cc", txtcc.Text);
                    cmd.Parameters.AddWithValue("@userid", user);
                    cmd.Parameters.AddWithValue("@uniqueid", uniq);
                    cmd.Parameters.AddWithValue("@licencenum", txtlicence.Text);
                    cmd.Parameters.AddWithValue("@rtoregion", DropDownList2.Text);
                    cmd.Parameters.AddWithValue("@status", "in Progress");

                


                    
                    cmd.ExecuteNonQuery();







                    string message2 = "Applied Successfully!!Your Unique Id is:  ";
                    string message3 = "   Please use this Id to check the application status";
                    ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + message2 + uniq + message3 + "');", true);
                    TextBox2.Text = DropDownList2.Text.Substring(0, 2);


                }
                catch (Exception ex)
                {
                    txtbody.Text = " ";
                    txtcc.Text = " ";
                    txtcolor.Text = " ";
                    txtcyclinder.Text = " ";
                    txtlicence.Text = " ";
                    txtengno.Text = "";
                    txtmfgdate.Text = "";
                    txtmodel.Text = "";
                    txtseating.Text = "";
                    txtwgt.Text = "";
                    DropDownList1.Text = "--Select--";
                    DropDownList2.Text = "--Select--";
                    string message1 = "Registration for this Vehicle is already in Progress!!";
                    ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + message1 + "');", true);
                    // MessageBox.Show(ex.ToString());

                }
            }
            else
            {
                string message = "failed to create unique Id.Try Again!!";
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + message + "');", true);
            }
            
        }
        else
        {
            string m1 = "Enter all fields!!";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m1 + "');", true);
        }
        
    }
    protected void btnFancySelect_Click(object sender, EventArgs e)
    {
        string s = "KA-" + DropDownList2.Text.Substring(0, 2) + "-" + TextBox3.Text + "-" + TextBox4.Text;
        SqlConnection con = new SqlConnection(@"server=INBASDPC12849\SQLEXPRESS;database=dbCasestudy;Integrated security=true");
        SqlCommand cmd = new SqlCommand("addFancy");
        cmd.CommandType = CommandType.StoredProcedure;
        con.Open();
        cmd.Connection = con;
        cmd.Parameters.AddWithValue("@uniqu1",uniq );
        cmd.Parameters.AddWithValue("@fancy",s );
         cmd.ExecuteNonQuery();
        con.Close();
        ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Fancy Number successfully selected!!')</script>");
    }
    protected void btnCheck_Click(object sender, EventArgs e)
    {
        if (((TextBox3.Text !="") && (TextBox4.Text != "")))
        {
            string s = "KA-" + DropDownList2.Text.Substring(0, 2) + "-" + TextBox3.Text + "-" + TextBox4.Text;
            SqlConnection con = new SqlConnection(@"server=INBASDPC12849\SQLEXPRESS;database=dbCasestudy;Integrated security=true");
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from tblFancynum where vFancynum =@fancy ", con);
        cmd.Parameters.AddWithValue("@fancy", s);
       
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        lblCheck.Visible = true;
        if (dt.Rows.Count > 0)
                {
                    
                    lblCheck.Text = "Not Available!!";

                }
                else
                {
                   
                    lblCheck.Text = "Available!!";
                    //lblCheck.Text = dt.Rows.Count.ToString();
                }
           
            con.Close();
        }
        else
        {

            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Enter Fancy Number!!')</script>");
        }
    }
}