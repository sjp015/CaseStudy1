﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Generation;
using System.Windows.Forms;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adk"] == null)
        {
            Response.Redirect("home.aspx");
        }
    }
   
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        if ((txtpan.Text != "") && (txtmobile.Text != "") && (txtfullname.Text != "") && (txtemail.Text != "") && (txtage.Text != "") && (txtaddr.Text != ""))
        {
            SqlConnection con = new SqlConnection(@"server=INBASDPC12849\SQLEXPRESS;database=dbCasestudy;Integrated security=true");
            SqlCommand cmd = new SqlCommand("UpdateSignupTbl");
            
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();


            cmd.Parameters.AddWithValue("@fullname", txtfullname.Text);
            cmd.Parameters.AddWithValue("@age", txtage.Text);
            cmd.Parameters.AddWithValue("@gender",RadioButtonList1.Text);
            cmd.Parameters.AddWithValue("@adddress", txtaddr.Text);
            cmd.Parameters.AddWithValue("@mobile", txtmobile.Text);
            cmd.Parameters.AddWithValue("@email", txtemail.Text);
            cmd.Parameters.AddWithValue("@pancard", txtpan.Text);
           
            cmd.Parameters.AddWithValue("@userid", Session["adk"].ToString());
            cmd.ExecuteNonQuery();







            string message2 = "Edited Profile Successfully!!";
           
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + message2 + "');", true);

            txtfullname.Text = "";
            txtage.Text = "";
            RadioButtonList1.Text = "";
            txtmobile.Text = "";
            txtemail.Text = "";
            txtpan.Text = "";
            txtaddr.Text = "";
        }
        else
        {
            string m = "Enter All Fields";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
        }
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtfullname.Text = "";
        txtage.Text = "";
        RadioButtonList1.Text = "";
        txtmobile.Text = "";
        txtemail.Text = "";
        txtpan.Text = "";
        txtaddr.Text = "";
        Server.Transfer("Registrationfrm.aspx");
    }
}