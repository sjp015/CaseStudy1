﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adk"] == null)
        {

            
            Response.Redirect("home.aspx");
        }
    }
    protected void btnApplyRegistration_Click(object sender, EventArgs e)
    {
        Response.Redirect("VehicleReg.aspx");
    }
    protected void btnCheckStatus_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserCheckStatus.aspx");
    }
    protected void btnChangePassword_Click(object sender, EventArgs e)
    {
        Response.Redirect("Change Password.aspx");
    }
    protected void btnEditProfile_Click(object sender, EventArgs e)
    {
        Response.Redirect("UpdatePage.aspx");
    }
}