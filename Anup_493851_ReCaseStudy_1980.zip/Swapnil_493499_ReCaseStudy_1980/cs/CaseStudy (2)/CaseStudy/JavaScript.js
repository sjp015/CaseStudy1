﻿
function userValid() 
{
    var Name,age, gender, mobile,mobileExp, EmailId, emailExp, panCard, panCardExp;
    Name = document.getElementById("txtfullname").value;
    age = document.getElementById("txtage").value;
    gender = document.getElementById("ddlType").value;
    mobile = document.getElementById("txtmobile").value;
    mobileExp = /^[7-9]\d{9}$/;
    EmailId = document.getElementById("txtmail").value;
    emailExp = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([com\co\.\in])+$/; // to validate email id
    panCard = document.getElementById("txtpan").value;
    panCardExp = /[A-Z]{5}\d{4}[A-Z]{1}/;


    if (Name == '' && gender == 0 && age == '' && mobile == '' && EmailId == '' && panCard == '')
    {
        alert( "Enter All Fields");
        return false;

    }

    if (Name == '') {
        alert("Please Enter the Name");
        return false;
    }
    if (age == 0) {
        alert("Please enter your age");
        return false;
    }
    if (gender == 0) {
        alert("Please Select gender");
        return false;
    }
    if ( mobile== '')
    {
        alert("Please Enter mobile number");
        return false;
    }
    if (mobile != '')
    {
        if(!mobile.match(mobileExp))
        {
            alert ("Invalid Mobile number");
            return false;
        }
    }

    if (EmailId == '')
    {
        alert("Email Id Is Required");
        return false;
    }
    if (EmailId != '')
    {
        if (!EmailId.match(emailExp)
        {
            alert("Invalid Email Id");
            return false;
        }
    }

    if (panCard == '')
    {
        alert("Enter Pan Card number");
        return false;
    }
    if (panCard != '')
    {
        if(!panCard.match(panCardExp))
        {
            alert ("Invalid Pan Card number");
            return false;
        }
    }
    return true;
}
