﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        if ((txtuserid.Text!="")&&(txtpassword.Text!=""))
        {
            SqlConnection con = new SqlConnection(@"server=INBASDPC12849\SQLEXPRESS;database=dbCasestudy;Integrated security=true");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from tblSignup where vUserId =@Username1 and vPassword=@Password1", con);
            cmd.Parameters.AddWithValue("@Username1", txtuserid.Text);
            cmd.Parameters.AddWithValue("@Password1", txtpassword.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {

                Session["adk"] = txtuserid.Text;
                Response.Redirect("UserProfile.aspx?Username=" + txtuserid.Text);

            }
            else
            {
                string m = "Invalid Username and Password ";
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
            }​ 
        }
        else
        {
            string m = "Enter all Fields";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
        }

    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtpassword.Text = "";
        txtuserid.Text = "";
        Server.Transfer("UserLogin.aspx");
    }
    protected void txtpassword_TextChanged(object sender, EventArgs e)
    {

    }
}