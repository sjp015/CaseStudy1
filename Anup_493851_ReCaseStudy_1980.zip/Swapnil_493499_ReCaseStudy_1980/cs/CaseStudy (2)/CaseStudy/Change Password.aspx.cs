﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adk"] == null)
        {
            Response.Redirect("home.aspx");
        }

    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtcrtpwd.Text = "";
        txtpassword.Text = "";
        txconfirmpwd.Text = "";
        Server.Transfer("Change Password.aspx");​
    }
    protected void btnsubmmit_Click(object sender, EventArgs e)
    {

        if ((txtcrtpwd.Text!="")&&(txconfirmpwd.Text!="")&&(txtpassword.Text!=""))
        {
            if (txtcrtpwd.Text == txconfirmpwd.Text)
            {
                if (txtcrtpwd.Text != txtpassword.Text)
                {
                    SqlConnection con = new SqlConnection(@"server=INBASDPC12849\SQLEXPRESS;database=dbCasestudy;Integrated security=true");
                    SqlCommand cmd = new SqlCommand("changepass");
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    cmd.Connection = con;
                    cmd.Parameters.AddWithValue("@crtpwd", txtpassword.Text);
                    cmd.Parameters.AddWithValue("@user", Session["adk"].ToString());
                    cmd.Parameters.AddWithValue("@txtpassword", txtcrtpwd.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    try
                    {
                        SqlCommand cmd1 = new SqlCommand("checkpass");
                        cmd1.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        cmd1.Connection = con;

                        cmd1.Parameters.AddWithValue("@user", Session["adk"].ToString());
                        cmd1.ExecuteNonQuery();


                        if (cmd1.ExecuteScalar().ToString() == txtcrtpwd.Text)
                        {
                            string m1 = "Password changed Successfully!!!";
                            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m1 + "');", true);
                        }
                        else
                        {
                            string m1 = "incorrect Password!!!";
                            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m1 + "');", true);
                        }
                        con.Close();
                    }
                    catch (Exception)
                    {
                        string m = "Excecution Failed..Try Again!!!";
                        ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
                    }
                }
                else
                {
                    string m = "Entered Same Password!!!";
                    ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);

                }
            }
            else
            {
                string m = "Retype Confirm password Properly!!!";
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
            } 
        }
        else
        {
            string m = "Enter All Fields!!!";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m + "');", true);
        }
    }

   
}