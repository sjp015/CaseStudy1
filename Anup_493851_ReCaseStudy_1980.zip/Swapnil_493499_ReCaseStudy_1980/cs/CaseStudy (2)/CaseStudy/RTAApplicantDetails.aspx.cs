﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adk"] == null)
        {
            Response.Redirect("home.aspx");
        }

        lblUniqID.Text = "Unique ID :  "+GridView1.Rows[0].Cells[0].Text;
        lblFullname.Text = "Full Name :  " + GridView1.Rows[0].Cells[1].Text;
        lblAge.Text = "Age :  " + GridView1.Rows[0].Cells[2].Text;
        lblAddress.Text = "Address :  " + GridView1.Rows[0].Cells[3].Text;
        lblPAN.Text = "Pan Card No. :  " + GridView1.Rows[0].Cells[4].Text;
        lblLicenceNumber.Text = "Licence No. :  " + GridView1.Rows[0].Cells[5].Text;
        lblEngine.Text="Engine No. :  "+GridView1.Rows[0].Cells[6].Text;
        lblModel.Text="Model :  "+GridView1.Rows[0].Cells[7].Text;
        lblBody.Text="Body :  "+GridView1.Rows[0].Cells[8].Text;
        lblColor.Text = "Color :  " + GridView1.Rows[0].Cells[9].Text;
        lblFuel.Text = "Fuel :  " + GridView1.Rows[0].Cells[10].Text;
        lblMfgDate.Text = "Mfg Date :  " + GridView1.Rows[0].Cells[11].Text;
        lblUnladenWgt.Text = "Unladen Weight :  " + GridView1.Rows[0].Cells[12].Text;
        lblNoOfCyl.Text = "No. of Cyllinders :  " + GridView1.Rows[0].Cells[13].Text;
        lblCC.Text = "CC :  " + GridView1.Rows[0].Cells[14].Text;
        lblSeating.Text = "Seating :  " + GridView1.Rows[0].Cells[15].Text;
        lblFancy.Text = "Fancy No. Applied :  " + GridView1.Rows[0].Cells[16].Text;
        lblRto.Text = "RTO :  " + GridView1.Rows[0].Cells[18].Text;
        lblStatus.Text = "Application Status :  " + GridView1.Rows[0].Cells[19].Text;

        if(GridView1.Rows[0].Cells[19].Text=="Approved By RTA")
        {
           
            TextBox1.Visible = false;
            Label2.Visible = true;
            Label2.Text = "Licence No. :  " + GridView1.Rows[0].Cells[17].Text;
        }
        else if (GridView1.Rows[0].Cells[19].Text == "Denied By RTA")
        {
             TextBox1.Visible = false;
            
        }

    }

    
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text !="")
        {
            Label2.Visible = true;
            TextBox1.Visible = false;

            SqlConnection con = new SqlConnection(@"server=INBASDPC12849\SQLEXPRESS;database=dbCasestudy;Integrated security=true");
            SqlCommand cmd = new SqlCommand("addFancyAsRegistered");
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@licenceP", TextBox1.Text);
            cmd.Parameters.AddWithValue("@uniqId", GridView1.Rows[0].Cells[0].Text);

            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("RTAApplicantDetails.aspx?uniqueId=" + GridView1.Rows[0].Cells[0].Text); 
        }
        else
        {
            string m1 = "Enter Licence Number";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + m1 + "');", true);
            Response.Redirect("RTAApplicantDetails.aspx?uniqueId=" + GridView1.Rows[0].Cells[0].Text);
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(@"server=INBASDPC12849\SQLEXPRESS;database=dbCasestudy;Integrated security=true");
        SqlCommand cmd = new SqlCommand("StatusChangedtoDenied");
        cmd.CommandType = CommandType.StoredProcedure;
        con.Open();
        cmd.Connection = con;

        cmd.Parameters.AddWithValue("@un", GridView1.Rows[0].Cells[0].Text);
        cmd.ExecuteNonQuery();
        con.Close();
      
        Response.Redirect("RTAApplicantDetails.aspx?uniqueId=" + GridView1.Rows[0].Cells[0].Text); 
    }
}