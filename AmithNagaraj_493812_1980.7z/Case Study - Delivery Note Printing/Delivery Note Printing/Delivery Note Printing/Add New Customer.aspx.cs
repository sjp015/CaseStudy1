﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Add_New_Customer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Manufacturer Id"] == null)
        {
            Response.Redirect("Login Page.aspx");
        }
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection connection = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
        connection.Open();
        SqlCommand command = new SqlCommand("insert into tblCustomers values (@vName, @vAddr,@vPhoneNum,@vPwd)",connection);
        command.Parameters.AddWithValue("@vName",txtCustomerName.Text);
        command.Parameters.AddWithValue("@vAddr", txtAddress.Text);
        command.Parameters.AddWithValue("@vPhoneNum", txtPhoneNo.Text);
        command.Parameters.AddWithValue("@vPwd", txtDefaultPssd.Text);
        command.ExecuteNonQuery();
        ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Customer Added')</script>");
        txtAddress.Text = string.Empty;
        txtCustomerName.Text = string.Empty;
        txtPhoneNo.Text = string.Empty;

    }
}