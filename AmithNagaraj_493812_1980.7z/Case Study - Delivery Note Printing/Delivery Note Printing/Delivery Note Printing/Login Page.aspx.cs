﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class ManufacturerLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session.RemoveAll();
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        SqlConnection connection = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
        connection.Open();

        SqlDataReader dr;

        if (rblMember.Text == "Manufacturer")
        {
            SqlCommand cmdManufacturer = new SqlCommand("SELECT * FROM tblManufacturer WHERE iMLogin_Id = @Id AND vMPwd=@pssd", connection);
            cmdManufacturer.Parameters.AddWithValue("@Id", txtboxUsername.Text);
            cmdManufacturer.Parameters.AddWithValue("@pssd", txtboxPassword.Text);
            dr = cmdManufacturer.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                Session["Manufacturer Id"] = dr.GetValue(0);
                Response.Redirect("Manufacturer.aspx");
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
            }
        }
        else if (rblMember.Text == "Customer")
        {
            SqlCommand cmdcustomer = new SqlCommand("SELECT * FROM tblCustomers WHERE iCustomer_Id=@Id AND vPwd=@pssd", connection);
            cmdcustomer.Parameters.AddWithValue("@Id", txtboxUsername.Text);
            cmdcustomer.Parameters.AddWithValue("@pssd", txtboxPassword.Text);
            dr = cmdcustomer.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                Session["Customer Id"] = (int)dr.GetValue(0);
                Response.Redirect("Customer.aspx");
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
            }
        }
    }

}
