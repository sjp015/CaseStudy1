﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient; 

public partial class Change_Password : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Session["Manufacturer Id"] == null && Session["Customer Id"] == null)
        {
            Response.Redirect("Login Page.aspx");
        }
    }
    protected void btnChangePassword_Click(object sender, EventArgs e)
    {
        if (Session["Manufacturer Id"] != null)
        {
            SqlConnection connection = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
            connection.Open();
            SqlCommand cmdManufacturer = new SqlCommand("SELECT * FROM tblManufacturer WHERE iMLogin_Id = @Id AND vMPwd=@pssd", connection);
            cmdManufacturer.Parameters.AddWithValue("@Id", Session["Manufacturer Id"]);
            cmdManufacturer.Parameters.AddWithValue("@pssd", txtboxCurrentPassword.Text);

            SqlDataReader dr;
            dr = cmdManufacturer.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Close();
                SqlCommand changepwdManufacturer = new SqlCommand("prcChangepwdManufacturer", connection);
                changepwdManufacturer.CommandType = CommandType.StoredProcedure;
                changepwdManufacturer.Parameters.AddWithValue("@Id", Session["Manufacturer Id"]);
                changepwdManufacturer.Parameters.AddWithValue("@NewPassword", txtboxNewpassword.Text);
                changepwdManufacturer.ExecuteNonQuery();
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Password Changed')</script>");
                emptystring();
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Current Password')</script>");
                emptystring();
            }
        }
        else if (Session["Customer Id"] != null)
        {
            SqlConnection connection = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
            connection.Open();
            SqlCommand cmdcustomer = new SqlCommand("SELECT * FROM tblCustomers WHERE iCustomer_Id=@Id AND vPwd=@pssd", connection);
            cmdcustomer.Parameters.AddWithValue("@Id", Session["Customer Id"]);
            cmdcustomer.Parameters.AddWithValue("@pssd", txtboxCurrentPassword.Text);

            SqlDataReader dr;
            dr = cmdcustomer.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Close();
                SqlCommand changepwdCustomer = new SqlCommand("prcChangepwdCustomer", connection);
                changepwdCustomer.CommandType = CommandType.StoredProcedure;
                changepwdCustomer.Parameters.AddWithValue("@Id", Session["Customer Id"]);
                changepwdCustomer.Parameters.AddWithValue("@NewPassword", txtboxNewpassword.Text);
                changepwdCustomer.ExecuteNonQuery();
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Password Changed')</script>");
                emptystring();
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Current Password')</script>");
                emptystring();
            }
        }
    }

    protected void emptystring()
    {
        txtboxCurrentPassword.Text = string.Empty;
        txtboxNewpassword.Text = string.Empty;
        txtboxReenterPassword.Text = string.Empty;
    }
}