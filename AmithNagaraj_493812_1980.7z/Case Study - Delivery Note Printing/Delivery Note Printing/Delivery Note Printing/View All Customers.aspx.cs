﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class View_All_Customers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Manufacturer Id"] == null)
        {
            Response.Redirect("Login Page.aspx");
        }
        else
        {
            SqlConnection connection = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
            connection.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter("prcViewCustomers", connection);
            da.Fill(ds);
            connection.Close();
            gridviewCustomers.DataSource = ds;
            gridviewCustomers.DataBind();
        }
    }
}