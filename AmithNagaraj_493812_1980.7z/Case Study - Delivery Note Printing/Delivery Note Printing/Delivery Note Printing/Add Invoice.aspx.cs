﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

public partial class Add_Invoice : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Manufacturer Id"] == null)
        {
            Response.Redirect("Login Page.aspx");
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
            SqlConnection connection = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
        try
        {
            connection.Open();

            SqlCommand command = new SqlCommand("prcAddInvoice", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@OrderId", txtboxOrderId.Text);
            command.Parameters.AddWithValue("@OrderDate", txtboxOrderDate.Text);
            command.Parameters.AddWithValue("@CustomerId", txtboxCustomerId.Text);
            command.Parameters.AddWithValue("@InvoiceAmount", txtboxInvoiceAmount.Text);
            command.Parameters.AddWithValue("@InvoiceDate", txtboxInvoiceDate.Text);
            command.ExecuteNonQuery();
            Response.Redirect("Manufacturer.aspx");
        }
        catch (System.Data.SqlClient.SqlException)
        {
            string message = string.Empty;
            SqlCommand commandorder = new SqlCommand("SELECT * FROM tblCustomers WHERE iCustomer_Id=@CustomerId",connection);
            commandorder.Parameters.AddWithValue("@CustomerId", txtboxCustomerId.Text);
            SqlDataReader dr;
            dr = commandorder.ExecuteReader();
            if (dr.HasRows)
            {
                message = "Order Id already exists";
            }
            else
            {
                message = "Customer Id does not exist";
            }
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + message + "');", true);
        }
    }
}