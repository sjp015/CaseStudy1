﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class View_Delivery_Note : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Manufacturer Id"] != null)
        {
            SqlConnection connection = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
            connection.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter("prcViewDeliveryNote", connection);
            da.Fill(ds);
            connection.Close();
            gridviewViewDeliveryNote.DataSource = ds;
            gridviewViewDeliveryNote.DataBind();
        }

        else
        {
            Response.Redirect("Login Page.aspx");
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
            SqlConnection connection = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
            connection.Open();
            SqlCommand command = new SqlCommand("prcViewDeliveryNoteCustomer", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Id", txtboxCustomerId.Text);
            SqlDataReader dr;
            dr = command.ExecuteReader();
            if (dr.HasRows)
            {
                Response.Redirect("View Delivery Note Customer.aspx?CustomerId=" + txtboxCustomerId.Text);
            }
            else
            {
                string message = "Customer Id does not exist";
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + message + "');", true);
            }

    }
}