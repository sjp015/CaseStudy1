﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Customer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session.Remove("Manufacturer Id");

        if(Session["Customer Id"]== null)
        {
            Response.Redirect("Login Page.aspx");
        }

       
    }
    protected void btnViewInvoice_Click(object sender, EventArgs e)
    {
        Response.Redirect("View Invoice Customer.aspx");
    }
    protected void btnViewDeliveryNote_Click(object sender, EventArgs e)
    {
        Response.Redirect("View Delivery Note Customer.aspx");
    }
}