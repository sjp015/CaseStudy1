﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Manufacturer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session.Remove("Customer Id");

        if (Session["Manufacturer Id"] == null)
        {
            Response.Redirect("Login Page.aspx");
        }
      
    }
   protected void lnkbtnAddNewCustomer_Click(object sender, EventArgs e)
    {
        Response.Redirect("Add New Customer.aspx");
    }
protected void lnkbtnAddInvoice_Click(object sender, EventArgs e)
{
    Response.Redirect("Add Invoice.aspx");
}
protected void lnkbtnAddDeliveryNote_Click(object sender, EventArgs e)
{
    Response.Redirect("Generate Delivery Note.aspx");
}
protected void lnkbtnViewCustomer_Click(object sender, EventArgs e)
{
    Response.Redirect("View All Customers.aspx");
}
protected void lnkbtnViewInvoice_Click(object sender, EventArgs e)
{
    Response.Redirect("View Invoice.aspx");
}
protected void lnkbtnViewDeliveryNote_Click(object sender, EventArgs e)
{
    Response.Redirect("View Delivery Note.aspx");
}
}