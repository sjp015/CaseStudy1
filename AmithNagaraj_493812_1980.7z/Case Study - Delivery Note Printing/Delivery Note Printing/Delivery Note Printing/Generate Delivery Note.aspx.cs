﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Generate_Delivery_Note : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Manufacturer Id"] == null)
        {
            Response.Redirect("Login Page.aspx");
        }
    }
    
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection connection = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
            SqlCommand command = new SqlCommand("prcAddDeliveryNote", connection);

            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@OrderId", txtboxOrderId.Text);
            command.Parameters.AddWithValue("@DateofDelivery", txtboxDateofDelivery.Text);
            command.Parameters.AddWithValue("@Quantity", txtboxQuantity.Text);
            command.Parameters.AddWithValue("@Description", txtboxDescription.Text);
            command.Parameters.AddWithValue("@SerialNo", txtboxSerialNumbers.Text);

            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();

            Response.Redirect("Login Page.aspx");
        }
        catch (Exception)
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Delivery Note already generated')</script>");
        }
    }
}