﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ManufacturerMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    public void lnkbtnMainmenu_Click(object sender,EventArgs e)
    {
        if(Session["Manufacturer Id"]!=null)
        {
            Response.Redirect("Manufacturer.aspx");
        }
        else if(Session["Customer Id"]!=null)
        {
            Response.Redirect("Customer.aspx");
        }
        else
        {
            Response.Redirect("Home Page.aspx");
        }
    }
    protected void lnkbtnChangePassword_Click(object sender, EventArgs e)
    {
        Response.Redirect("Change Password.aspx");
    }
    protected void lnkbtnLogOut_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("Login Page.aspx");
    }
}
