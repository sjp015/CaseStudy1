﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using iTextSharp.text;
using iTextSharp.text.pdf;

public partial class View_Invoice_Customer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Customer Id"] != null)
        {
            SqlConnection connection = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
            connection.Open();
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand("prcViewInvoiceCustomer", connection);
            cmd.Parameters.AddWithValue("@Id", Session["Customer Id"]);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            gridviewInvoice.DataSource = ds;
            gridviewInvoice.DataBind();
        }
        else if (Session["Manufacturer Id"] != null)
        {
            SqlConnection connection = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
            connection.Open();
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand("prcViewInvoiceCustomer", connection);
            cmd.Parameters.AddWithValue("@Id", Request.QueryString["CustomerId"]);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            gridviewInvoice.DataSource = ds;
            gridviewInvoice.DataBind();
        }
        else
        {
            Response.Redirect("Login Page.aspx");
        }
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        try
        {

            SqlConnection con = new SqlConnection(@"Server=INBASDPC12757;Database=dbCaseStudy;Integrated Security=true");
            SqlCommand cmd = new SqlCommand("prcViewInvId", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter();
            cmd.CommandType = CommandType.StoredProcedure;

            da.SelectCommand = cmd;
            cmd.Parameters.AddWithValue("@Id", txtboxEnterInvoice.Text);
            da.Fill(dt);
            DataRow dr = dt.Rows[0];


            Document document = new Document(PageSize.A4, 25, 25, 25, 25);
            System.IO.MemoryStream memoryStream = new System.IO.MemoryStream();
            PdfWriter pdfWriter = PdfWriter.GetInstance(document, Response.OutputStream);
            PdfPTable table = null;
            PdfPCell cell = null;
            document.Open();

            Paragraph para = new Paragraph(" ");
            para.SpacingBefore = 20;
            para.SpacingAfter = 20;
            para.Alignment = 1; //'0-Left, 1 middle,2 Right
            document.Add(para);

            table = new PdfPTable(1);
            table.SetWidths(new float[] { 2f });
            table.TotalWidth = 500f;
            table.LockedWidth = true;
            table.SpacingBefore = 20f;
            table.SpacingAfter = 30f;
            table.HorizontalAlignment = Element.ALIGN_CENTER;
            cell = PhraseCell(new Phrase("\nInvoice", FontFactory.GetFont("Arial", 20, BaseColor.BLUE)), PdfPCell.ALIGN_CENTER);
            cell.Colspan = 3;
            cell.PaddingBottom = 30f;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            cell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
            cell.Colspan = 3;
            table.AddCell(cell);
            document.Add(table);

            Paragraph p = new Paragraph();
            p.Alignment = 1;
            p.Add(new Chunk("Order Id : ", FontFactory.GetFont("Arial", 14, Font.BOLD, BaseColor.BLACK)));
            p.Add(new Chunk(dr["Order Id"].ToString(), FontFactory.GetFont("Arial", 14, BaseColor.BLACK)));
            p.Add(new Chunk("\n\nCustomer Id :  ", FontFactory.GetFont("Arial", 14, Font.BOLD, BaseColor.BLACK)));
            p.Add(new Chunk(dr["Customer Id"].ToString(), FontFactory.GetFont("Arial", 14, BaseColor.BLACK)));
            p.Add(new Chunk("\n\nInvoice Number  :  ", FontFactory.GetFont("Arial", 14, Font.BOLD, BaseColor.BLACK)));
            p.Add(new Chunk(dr["Invoice number"].ToString(), FontFactory.GetFont("Arial", 14, BaseColor.BLACK)));
            p.Add(new Chunk("\n\nInvoice Date  :  ", FontFactory.GetFont("Arial", 14, Font.BOLD, BaseColor.BLACK)));
            p.Add(new Chunk(dr["Invoice Date"].ToString(), FontFactory.GetFont("Arial", 14, BaseColor.BLACK)));
            p.Add(new Chunk("\n\nInvoice Amount :  ", FontFactory.GetFont("Arial", 14, Font.BOLD, BaseColor.BLACK)));
            p.Add(new Chunk(dr["Invoice Amount"].ToString(), FontFactory.GetFont("Arial", 14, BaseColor.BLACK)));
            document.Add(p);

            PdfContentByte content = pdfWriter.DirectContent;
            iTextSharp.text.Rectangle rectangle = new iTextSharp.text.Rectangle(document.PageSize);
            rectangle.Left += document.LeftMargin;
            rectangle.Right -= document.RightMargin;
            rectangle.Top -= document.TopMargin;
            rectangle.Bottom += document.BottomMargin;
            content.SetColorStroke(iTextSharp.text.BaseColor.RED);
            content.Rectangle(rectangle.Left, rectangle.Bottom, rectangle.Width, rectangle.Height);
            content.Rectangle(rectangle.Left, rectangle.Bottom, rectangle.Width, rectangle.Height);
            content.Stroke();

            pdfWriter.CloseStream = false;
            document.Close();
            Response.Buffer = true;
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=Invoice.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Write(document);
            Response.End();
        }
        catch(Exception)
        {
            string message = "Invalid Invoice Number";
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + message + "');", true);
        }
    }

    private static PdfPCell PhraseCell(Phrase phrase, int align)
    {
        PdfPCell cell = new PdfPCell(phrase);
        cell.BorderColor = BaseColor.BLACK;
        cell.VerticalAlignment = PdfPCell.ALIGN_TOP;
        cell.HorizontalAlignment = align;
        cell.PaddingBottom = 2f;
        cell.PaddingTop = 2f;
        return cell;

    }


}