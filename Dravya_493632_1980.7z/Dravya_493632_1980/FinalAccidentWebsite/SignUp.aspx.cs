﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Data;

public partial class SignUp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
       
     
       
        //establishing connection with the database

        SqlConnection con = new SqlConnection(@"Server=INBASDPC12643;Database=dbAccidentInsurance;Integrated Security=true;");


        //creating sql command object to store the insert command

        SqlCommand cmd = new SqlCommand("prcInsertUser", con);

        //SqlDataAdapter da = new SqlDataAdapter();
        cmd.CommandType = CommandType.StoredProcedure;


        SqlParameter p1= new SqlParameter("@UserName", TextBoxName.Text);
        SqlParameter p2= new SqlParameter("@UserEmail",TextBox2.Text);
        SqlParameter p3= new SqlParameter("@UserPassword", TextBox5.Text);

        cmd.Parameters.Add(p1);
        cmd.Parameters.Add(p2);
        cmd.Parameters.Add(p3);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        Response.Redirect("Home.aspx");

                 
    }

    protected void tbName_TextChanged(object sender, EventArgs e)
    {

    }
}