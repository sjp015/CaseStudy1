﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;



public partial class BuyInsuranceForm : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }
  
    protected void Button1_Click(object sender, EventArgs e)
    {
       
        //establishing connection with the database

        SqlConnection con = new SqlConnection(@"Server=INBASDPC12643;Database=dbAccidentInsurance;Integrated Security=true;");


        //creating sql command object to store the insert command

        SqlCommand cmd = new SqlCommand("prcInsertPersonalDetails", con);

        //SqlDataAdapter da = new SqlDataAdapter();
        cmd.CommandType = CommandType.StoredProcedure;


        SqlParameter p1 = new SqlParameter("@UserName" ,TextBox1.Text);
        SqlParameter p2 = new SqlParameter( "@ContactNumber",TextBox2.Text);
        SqlParameter p3 = new SqlParameter( "@EmailId",TextBox3.Text);
        SqlParameter p4 = new SqlParameter ("@Gender",RadioButtonList1.SelectedValue);
        SqlParameter p5 = new SqlParameter("@MaritialStatus",RadioButtonList2.SelectedValue );
        SqlParameter p6 = new SqlParameter("@AnnualIncome", TextBox4.Text);

        cmd.Parameters.Add(p1);
        cmd.Parameters.Add(p2);
        cmd.Parameters.Add(p3);
        cmd.Parameters.Add(p4);
        cmd.Parameters.Add(p5);
        cmd.Parameters.Add(p6);
      
        con.Open();
        cmd.ExecuteNonQuery();
        Session["Params"] = TextBox1.Text;
        con.Close();

        Response.Redirect("BuyInsuranceForm1.aspx");
    }


  


    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {


    }
}

    
