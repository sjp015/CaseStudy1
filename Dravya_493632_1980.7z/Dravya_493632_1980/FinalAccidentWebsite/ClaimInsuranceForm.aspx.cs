﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class ClaimInsuranceForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //try
        //{
            SqlConnection con = new SqlConnection(@"Server=INBASDPC12643;Database=dbAccidentInsurance;Integrated Security=true;");

            SqlCommand cmd = new SqlCommand("Insert into tblClaimInsurance values (@PolicyNumber,@InjuredName ,@InjuryDate  ,@InjuryTime ,@InjuryType ) ", con);
            cmd.Parameters.AddWithValue("@PolicyNumber", TextBox1.Text);
            cmd.Parameters.AddWithValue("@InjuredName ", TextBox2.Text);
            cmd.Parameters.AddWithValue("@InjuryDate ", TextBox3.Text);
            cmd.Parameters.AddWithValue("@InjuryTime ", TextBox4.Text);
            cmd.Parameters.AddWithValue("@InjuryType  ", DropDownList1.SelectedValue);

            con.Open();
            cmd.ExecuteNonQuery();


            SqlCommand cmd1 = new SqlCommand("select InsuredAmount from tblInsuredDetails");
            int Amount = Convert.ToInt32(cmd1.ExecuteScalar());


            if (DropDownList1.SelectedValue.ToString() == "Death")
            {
                Amount = Amount * 1;
            }
            else if (DropDownList1.SelectedValue.ToString() == "Blindness – one eye")
            {
                Amount = Amount * (4 / 10);
            }
            else if (DropDownList1.SelectedValue.ToString() == "Blindness – both eyes")
            {
                Amount = Amount * (9 / 10);
            }
            else if (DropDownList1.SelectedValue.ToString() == "Amputation of one limb or One upper and lower limbs")
            {
                Amount = Amount / 2;
            }
            else if (DropDownList1.SelectedValue.ToString() == "Amputation of  two limbs or Both upper and lower limbs")
            {
                Amount = Amount * (95 / 100);
            }
            else if (DropDownList1.SelectedValue.ToString() == "Injuries requiring hospitalization")
            {
                Amount = Amount * (35 / 100);
            }
            else if (DropDownList1.SelectedValue.ToString() == "Injuries not requiring hospitalization")
            {
                Amount = Amount * (15 / 100);
            }

            string display = "Message Pop-up!";
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + display + "');", true);


            Response.AddHeader("REFRESH", "0 ;URL=Home.aspx");


            //Response.Redirect("Home.aspx");
            con.Close();
        }
        //catch
        //{
        //    label12.text=
        //        Response.Redirect

        //}
        
   
    
   
}

   
