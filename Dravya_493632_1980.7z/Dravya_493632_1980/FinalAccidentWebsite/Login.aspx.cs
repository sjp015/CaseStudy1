﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Login : System.Web.UI.Page
{
    int check;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //establishing connection with the database

        SqlConnection con = new SqlConnection(@"Server=INBASDPC12643;Database=dbAccidentInsurance;Integrated Security=true;");


        //creating sql command object to store the insert command

        SqlCommand cmd = new SqlCommand("prcCheckUser", con);

        //SqlDataAdapter da = new SqlDataAdapter();
        cmd.CommandType = CommandType.StoredProcedure;

        con.Open();
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
        Response.AddHeader("REFRESH" ,"0 ;URL=Home.aspx");

        //int check = Convert.ToInt32(cmd.ExecuteScalar());
        //if (check > 0)
        //{
        //    //Response.Redirect("Home.aspx");
           
        //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
        //    Response.AddHeader("REFRESH", "5;URL=Home.aspx");
        
        //}
        con.Close();



    }
    protected void Button2_Click(object sender, EventArgs e)
    {

    }
}