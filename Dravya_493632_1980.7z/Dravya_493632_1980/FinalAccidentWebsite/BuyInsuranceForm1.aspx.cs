﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class BuyInsuranceForm1 : System.Web.UI.Page
{
    string abc;
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
        //establishing connection with the database

            abc = Session["params"].ToString();
            string a = null;

            SqlConnection con = new SqlConnection(@"Server=INBASDPC12643;Database=dbAccidentInsurance;Integrated Security=true;");
            SqlCommand cmd1 = new SqlCommand("select PolicyNumber from tblPersonalDetails where UserName=@as", con);
            cmd1.Parameters.AddWithValue("@as", abc);
            con.Open();
            SqlDataReader reader = cmd1.ExecuteReader();
            while (reader.Read())
            {
                a = reader[0].ToString();
            }
            con.Close();
            //creating sql command object to store the insert command

            SqlCommand cmd = new SqlCommand("Insert into tblAddress values (@PolicyNumber,@AddStreet,@AddCity,@AddState,@AddCountry,@AddPinCode) ", con);
            cmd.Parameters.AddWithValue("@PolicyNumber", a.ToString());
            cmd.Parameters.AddWithValue("@AddStreet", TextBox1.Text);
            cmd.Parameters.AddWithValue("@AddCity", TextBox2.Text);
            cmd.Parameters.AddWithValue("@AddState", TextBox3.Text);
            cmd.Parameters.AddWithValue("@AddCountry", TextBox4.Text);
            cmd.Parameters.AddWithValue("@AddPinCode", TextBox5.Text);

            
            con.Open();
            
            cmd.ExecuteNonQuery();
             
            con.Close();

            Response.Redirect("BuyInsuranceForm2.aspx");
        }
      

    
    }
