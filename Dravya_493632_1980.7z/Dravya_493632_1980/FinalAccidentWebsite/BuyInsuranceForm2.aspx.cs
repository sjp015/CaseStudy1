﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class BuyInsuranceForm2 : System.Web.UI.Page
{
    string abc;
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        abc = Session["params"].ToString();
        string a = null;

        SqlConnection con = new SqlConnection(@"Server=INBASDPC12643;Database=dbAccidentInsurance;Integrated Security=true;");
        SqlCommand cmd1 = new SqlCommand("select PolicyNumber from tblPersonalDetails where UserName=@as", con);
        cmd1.Parameters.Add("@as", abc);
        con.Open();
        SqlDataReader reader = cmd1.ExecuteReader();
        while (reader.Read())
        {
            a = reader[0].ToString();
        }
        con.Close();


        //SqlCommand cmd = new SqlCommand("Insert into tblInsuredDetails values/*(@PolicyNumber,@DateOfBirth,@InsuredOccupation,@InsuredAmount,@NomineeName,@NomineeRelation,@NomineeDOB)*/", con);
        SqlCommand cmd = new SqlCommand("Insert into tblInsuredDetails (@DateOfBirth,@InsuredOccupation,@InsuredAmount,@NomineeName,@NomineeRelation,@NomineeDOB)values(345678,'businesss',1234,'nehu','cousion',123456)");
            cmd.Parameters.Add("@PolicyNumber",a.ToString());
            cmd.Parameters.Add("@DateOfBirth", TextBox1.Text);
            cmd.Parameters.Add("@InsuredOccupation", TextBox2.Text);
            cmd.Parameters.Add("@InsuredAmount", TextBox5.Text);
            cmd.Parameters.Add("@NomineeName", TextBox3.Text);
            cmd.Parameters.Add("@NomineeRelation", RadioButtonList1.SelectedValue);
            cmd.Parameters.Add("@NomineeDOB", TextBox4.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            Response.Redirect("BuyInsuranceForm3.aspx");
        }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }


    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

    }
}