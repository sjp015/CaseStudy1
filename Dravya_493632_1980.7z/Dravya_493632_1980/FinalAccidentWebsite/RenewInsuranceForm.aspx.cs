﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class RenewInsuranceForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //establishing connection with the database


        string a = null;

        SqlConnection con = new SqlConnection(@"Server=INBASDPC12643;Database=dbAccidentInsurance;Integrated Security=true;");



        //creating sql command object to store the insert command

        SqlCommand cmd = new SqlCommand("Insert into tblRenewInsurance values ( @PolicyNumber,@ DOB ,@RenewYear ,@RenewAmount)", con);
        cmd.Parameters.AddWithValue("@PolicyNumber", a);
        cmd.Parameters.AddWithValue("@ DOB", TextBox1.Text);
        cmd.Parameters.AddWithValue("@RenewYear  ", RadioButtonList1.SelectedValue);
        cmd.Parameters.AddWithValue("@RenewAmount  ", RadioButtonList2.SelectedValue);
      

        con.Open();
        cmd.ExecuteNonQuery();
        Session["asc"] = a;
        con.Close();

        Response.Redirect("BuyInsuranceForm2.aspx");
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}