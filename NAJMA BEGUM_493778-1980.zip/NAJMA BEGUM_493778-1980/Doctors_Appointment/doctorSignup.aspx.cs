﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;

public partial class doctorSignup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand("existance", con);
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@username", txtUserName.Text);
            SqlDataReader rd = command.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();
                this.msgDisplay.ForeColor = System.Drawing.Color.Red;
                this.msgDisplay.Font.Bold = true;
                this.msgDisplay.Text = "username already Exist!";
            }
            else
            {
                insertintodatabase();
                Session["UserName"] = txtUserName.Text;
                Response.Redirect("DoctorLoginForm.aspx");
            }
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void insertintodatabase()
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;
            command.CommandText = "fordoctorSignUP";
            command.Parameters.AddWithValue("@name", DropDownList1.SelectedValue);
            command.Parameters.AddWithValue("@username", txtUserName.Text);
            command.Parameters.AddWithValue("@pwd", txtPassword.Text);
            command.Parameters.AddWithValue("@q1", txtq1.Text);
            command.Parameters.AddWithValue("@q2", txtq2.Text);
            command.Parameters.AddWithValue("@q3", txtq3.Text);
            command.ExecuteNonQuery();
            Response.Write("<script>alert('SUCCESSFULLY REGISTERED');</script>");
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    
}