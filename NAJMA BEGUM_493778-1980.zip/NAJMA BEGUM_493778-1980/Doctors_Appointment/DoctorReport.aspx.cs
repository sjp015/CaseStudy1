﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf.fonts;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDcName.DataSource = GetData("SELECT vDoctorName,iDoctorId FROM doctorList");
            DropDcName.DataTextField = "vDoctorName";
            DropDcName.DataValueField = "iDoctorId";
            DropDcName.DataBind();
        }

    }
    protected void ButtonLeave_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void ButtonDaily_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }
    protected void ButtonInpatient_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;

    }
    protected void ButtonOutpatient_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 3;
    }
    protected void ButtonGenerate_Click(object sender, EventArgs e)
    {
        try
        {
            PdfPTable pdftable = new PdfPTable(GridView3.HeaderRow.Cells.Count);
            foreach (TableCell headercell in GridView3.HeaderRow.Cells)
            {
                Font font = new Font();
                font.Color = new BaseColor(GridView3.HeaderRow.ForeColor);
                PdfPCell pdfcell = new PdfPCell(new Phrase(headercell.Text));
                pdfcell.BackgroundColor = new BaseColor(GridView3.HeaderStyle.BackColor);
                pdftable.AddCell(pdfcell);
            }
            foreach (GridViewRow gridviewrow in GridView3.Rows)
            {
                foreach (TableCell tablecell in gridviewrow.Cells)
                {
                    PdfPCell pdfcell = new PdfPCell(new Phrase(tablecell.Text));
                    pdftable.AddCell(pdfcell);
                }
            }
            Document document = new Document(PageSize.A4, 25, 25, 25, 25);
            PdfWriter pdfWriter = PdfWriter.GetInstance(document, Response.OutputStream);
            PdfPTable table = null;
            PdfPCell cell = null;
            BANNER(document, pdfWriter, ref table, ref cell);
            Paragraph para = new Paragraph("LEAVE REPORT");
            para.SpacingBefore = 20;
            para.SpacingAfter = 20;
            para.Alignment = 1;
            document.Add(para);
            document.Add(pdftable);
            document.Close();
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=doctor leave report.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Write(document);
            Response.Flush();
            Response.End();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }

    protected void ButtonGen_Click(object sender, EventArgs e)
    {
        try
        {
            PdfPTable pdftable = new PdfPTable(GridView1.HeaderRow.Cells.Count);
            foreach (TableCell headercell in GridView1.HeaderRow.Cells)
            {
                Font font = new Font();
                font.Color = new BaseColor(GridView1.HeaderRow.ForeColor);
                PdfPCell pdfcell = new PdfPCell(new Phrase(headercell.Text));
                pdfcell.BackgroundColor = new BaseColor(GridView1.HeaderStyle.BackColor);
                pdftable.AddCell(pdfcell);
            }
            foreach (GridViewRow gridviewrow in GridView1.Rows)
            {
                foreach (TableCell tablecell in gridviewrow.Cells)
                {
                    PdfPCell pdfcell = new PdfPCell(new Phrase(tablecell.Text));
                    pdftable.AddCell(pdfcell);
                }
            }
            Document document = new Document(PageSize.A4, 25, 25, 25, 25);
            PdfWriter pdfWriter = PdfWriter.GetInstance(document, Response.OutputStream);
            PdfPTable table = null;
            PdfPCell cell = null;
            document.Open();
            BANNER(document, pdfWriter, ref table, ref cell);
            Paragraph para = new Paragraph("INPATIENT REPORT");
            para.SpacingBefore = 20;
            para.SpacingAfter = 20;
            para.Alignment = 1;
            document.Add(para);
            document.Add(pdftable);
            document.Close();
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=doctor inpatient report.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Write(document);
            Response.Flush();
            Response.End();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
       
    }
    private DataTable GetData(string query)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand cmd = new SqlCommand(query);
        using (SqlDataAdapter da = new SqlDataAdapter())
        {
            cmd.Connection = con;
            con.Open();
            da.SelectCommand = cmd;
            using (DataTable dt = new DataTable())
            {
                da.Fill(dt);
                return dt;
            }
        }
    }
    private static void BANNER(Document document, PdfWriter pdfWriter, ref PdfPTable table, ref PdfPCell cell)
    {
        Paragraph para = new Paragraph(" ");
        para.SpacingBefore = 20;
        para.SpacingAfter = 20;
        para.Alignment = 1; //'0-Left, 1 middle,2 Right
        document.Add(para);

        table = new PdfPTable(1);
        table.SetWidths(new float[] { 2f });
        table.TotalWidth = 500f;
        table.LockedWidth = true;
        table.SpacingBefore = 20f;
        table.SpacingAfter = 30f;
        table.HorizontalAlignment = Element.ALIGN_CENTER;
        cell = PhraseCell(new Phrase("\nANDHRA PRADESH GENERAL HOSPITAL", FontFactory.GetFont("Arial", 20, Font.BOLDITALIC, BaseColor.BLUE)), PdfPCell.ALIGN_CENTER);
        cell.Colspan = 3;
        cell.PaddingBottom = 30f;
        cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
        cell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
        cell.Colspan = 3;
        table.AddCell(cell);
        document.Add(table);

        PdfContentByte content = pdfWriter.DirectContent;
        iTextSharp.text.Rectangle rectangle = new iTextSharp.text.Rectangle(document.PageSize);
        rectangle.Left += document.LeftMargin;
        rectangle.Right -= document.RightMargin;
        rectangle.Top -= document.TopMargin;
        rectangle.Bottom += document.BottomMargin;
        content.SetColorStroke(iTextSharp.text.BaseColor.RED);
        content.Rectangle(rectangle.Left, rectangle.Bottom, rectangle.Width, rectangle.Height);
        content.Rectangle(rectangle.Left, rectangle.Bottom, rectangle.Width, rectangle.Height);
        content.Stroke();
    }
   
    private static PdfPCell PhraseCell(Phrase phrase, int align)
    {
        PdfPCell cell = new PdfPCell(phrase);
        cell.BorderColor = BaseColor.BLACK;
        cell.VerticalAlignment = PdfPCell.ALIGN_TOP;
        cell.HorizontalAlignment = align;
        cell.PaddingBottom = 2f;
        cell.PaddingTop = 2f;
        return cell;
    }
    protected void ButtGenerateRep_Click(object sender, EventArgs e)
    {
        //Report for Outpatient
        PdfPTable pdftable = new PdfPTable(GridView2.HeaderRow.Cells.Count);
        foreach (TableCell headercell in GridView2.HeaderRow.Cells)
        {
            Font font = new Font();
            font.Color = new BaseColor(GridView2.HeaderRow.ForeColor);
            PdfPCell pdfcell = new PdfPCell(new Phrase(headercell.Text));
            pdfcell.BackgroundColor = new BaseColor(GridView2.HeaderStyle.BackColor);
            pdftable.AddCell(pdfcell);
        }
        foreach (GridViewRow gridviewrow in GridView2.Rows)
        {
            foreach (TableCell tablecell in gridviewrow.Cells)
            {
                PdfPCell pdfcell = new PdfPCell(new Phrase(tablecell.Text));
                pdftable.AddCell(pdfcell);
            }
        }
        Document document = new Document(PageSize.A4, 25, 25, 25, 25);
        PdfWriter pdfWriter = PdfWriter.GetInstance(document, Response.OutputStream);
        PdfPTable table = null;
        PdfPCell cell = null;
        BANNER(document, pdfWriter, ref table, ref cell);
        Paragraph para = new Paragraph("OUTPATIENT REPORT");
        para.SpacingBefore = 20;
        para.SpacingAfter = 20;
        para.Alignment = 1;
        document.Add(para);
        document.Add(pdftable);
        document.Close();
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=doctor outpatient report.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Write(document);
        Response.Flush();
        Response.End();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand cmd = new SqlCommand("select vFirstName,vLastName,dDateOfAdmission,tAdmissionTime,vDepartmentName ,vDoctorName,vWardType   FROM inpatient_department where iDoctorID=" + DropDcName.SelectedItem.Value);
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        try
        {
            cmd.Connection = con;
            con.Open();
            da.SelectCommand = cmd;
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand cmd = new SqlCommand("select vPatientName,dAppointmentDate , tAppointmentTime,vDepartment , vDoctorName ,iAppointmentNumber,iReceptionisId FROM outpatientAppointments where iDoctorID=" + DropDcName.SelectedItem.Value);
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        try
        {
            cmd.Connection = con;
            con.Open();
            da.SelectCommand = cmd;
            da.Fill(ds);
            GridView2.DataSource = ds;
            GridView2.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand cmd = new SqlCommand("select * FROM doctorLeave where iDoctorID=" + DropDcName.SelectedItem.Value);
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        try
        {
            cmd.Connection = con;
            con.Open();
            da.SelectCommand = cmd;
            da.Fill(ds);
            GridView3.DataSource = ds;
            GridView3.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
}