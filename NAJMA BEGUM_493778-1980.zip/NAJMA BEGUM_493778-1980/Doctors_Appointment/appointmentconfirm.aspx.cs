﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ButtonSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("select  vPatientName AS[PATIENT NAME],dAppointmentDate AS [APPOINTMENT DATE],tAppointmentTime AS [APPOINTMENT TIME],vDepartment AS [DEPARTMENT NAME],vDoctorName AS[DOCTOR NAME],iReceptionisId AS [APPROVED BY RECEPTIONIST],cConfirmation AS [CONFIRMATION STATUS] FROM outpatientAppointments WHERE iAppointmentNumber=@num", con);
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@num", Textapp.Text);
            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "outpatientAppointments");
            GVstatus.DataSource = ds;
            GVstatus.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
}