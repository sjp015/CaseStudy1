﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data.SqlTypes;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void btnApply_Click1(object sender, EventArgs e)
    {
        
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "insertNameIntoDocLeave";
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            SqlParameter inParam = new SqlParameter();

            inParam.SqlDbType = System.Data.SqlDbType.Int;

            inParam.ParameterName = "@id";

            inParam.Direction = System.Data.ParameterDirection.Input;

            inParam.Value = txtId.Text;

            cmd.Parameters.Add(inParam);

            SqlParameter parm2 = new SqlParameter("@name", SqlDbType.VarChar);
            parm2.Size = 30;
            parm2.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parm2);
            SqlParameter parm3 = new SqlParameter("@depname", SqlDbType.VarChar);
            parm3.Size = 20;
            parm3.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parm3);
            cmd.ExecuteNonQuery();

            string doctorName = cmd.Parameters["@name"].Value.ToString();
            string doctordepName = cmd.Parameters["@depname"].Value.ToString();
            con.Close();
            insertLeave(doctorName, doctordepName);

        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }

    protected void insertLeave(string doctorName, string doctordepName)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        SqlCommand command = new SqlCommand();
        command.CommandText = "applyLeave";
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@id", txtId.Text);
            command.Parameters.AddWithValue("@name", doctorName);
            command.Parameters.AddWithValue("@date", txtDate.Text);
            command.Parameters.AddWithValue("@depname", doctordepName);
            command.Parameters.AddWithValue("@deptId", ddlLeave.SelectedValue);
            command.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('YOUR LEAVE HAS BEEN APPLIED');</script>");
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void btnCancel_Click1(object sender, EventArgs e)
    {
        int i;
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        SqlCommand command = new SqlCommand();
        command.CommandText = "cancelLeave";
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@id", txtIdCancel.Text);
            command.Parameters.AddWithValue("@date", txtDateCancel.Text);
            i = Convert.ToInt32(command.ExecuteNonQuery());
            con.Close();
            switch (i)
            {

                case 1:
                    {
                        Response.Write("<script>alert('YOUR LEAVE HAS BEEN CANCELLED');</script>");
                        break;
                    }

                case 2:
                    {
                        Response.Write("<script>alert('YOU HAVE NOT APPLIED LEAVE ON THE SELECTED DATE');</script>");
                        break;
                    }
                default:
                    {
                        Response.Write("<script>alert('OOPS! WRONG DATA, PLEASE TRY AGAIN');</script>");
                        break;
                    }
            }
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
}