﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnInpatient_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void btnOutpatient_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("SELECT  vFirstName AS [PATIENT NAME],dDateOfAdmission AS [DATE OF ADMISSION],vDoctorName AS [DOCTOR INCHARGE],vWardType AS [ADMITTED IN],COUNT(*) AS [NUMBER OF PATIENTS] FROM inpatient_department WHERE vDepartmentName=@dept GROUP BY vFirstName,dDateOfAdmission,vDoctorName,vWardType", con);
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@dept", ddlInpatientName.SelectedValue);
            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "inpatient_department");
            gvInpatientDetails.DataSource = ds;
            gvInpatientDetails.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
   
    protected void btnCheck_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("SELECT  vPatientName AS [PATIENT NAME],vDepartment AS [DEPARTMENT],vDoctorName AS [DOCTOR INCHARGE],iReceptionisId AS [ADMITTED BY] FROM  outpatientAppointments WHERE dAppointmentDate=@date", con);
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@date", txtdATE.Text);
            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "outpatientAppointments");
            gvOutpatientList.DataSource = ds;
            gvOutpatientList.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
}