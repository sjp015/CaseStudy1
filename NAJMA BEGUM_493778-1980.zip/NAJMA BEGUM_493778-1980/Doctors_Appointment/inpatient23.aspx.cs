﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Data.SqlTypes;
using System.Windows.Forms;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       if(Session["username"]!=null)
       {
           lblPay.Text = Session["username"].ToString();
       }
    }
    protected void btnSub_Click(object sender, EventArgs e)
    {
        int i;
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();
        command.CommandText = "forCheckingAmtEnteredInpatient";
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@name", lblPay.Text);
            command.Parameters.AddWithValue("@ipamt", TextAmt.Text);
            i = Convert.ToInt32(command.ExecuteScalar());
            con.Close();
            switch (i)
            {
                case 1:
                    {
                        Response.Write("<script>alert('SORRY, YOU HAVE ENTERED WRONG AMOUNT, PLEASE TRY AGAIN');</script>");
                        break;
                    }
                default:
                    {
                        insertAmount();
                        setConfirmationStatusForPayment();
                        break;
                    }
            }
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }

    protected void insertAmount()
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();
        command.CommandText = "forInpatientPayment";
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@name", lblPay.Text);
            command.Parameters.AddWithValue("@iAccNum", TextAccNum.Text);
            command.Parameters.AddWithValue("@vIfsc", TextIfsc.Text);
            command.Parameters.AddWithValue("@ipamt", TextAmt.Text);
            command.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('THANKYOU, YOUR PAYMENT HAS BEEN RECEIVED');</script>");
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }

    protected void setConfirmationStatusForPayment()
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();
        command.CommandText = "confirmInpatientPay";
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@name", lblPay.Text);
            command.ExecuteNonQuery();
            con.Close();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void ButtonMakePay_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }
    protected void ButtonCheckPay_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void btnCheck_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("SELECT vFirstName AS[PATIENT NAME],iPaymentAmount AS [BILL AMOUNT] from inpatientPaymentRecord WHERE vRegistrationRecord=@rid ", con);
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@rid", TextID.Text);

            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "inpatientPaymentRecord");
            GVPAY.DataSource = ds;
            GVPAY.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
}