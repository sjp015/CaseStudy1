﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnBookAppointment_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void btnCancelMe_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int i;
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();  
        command.CommandText = "forOutPatientBookingAppointment";
         command.CommandType = CommandType.StoredProcedure;
         try
         {
             con.Open();
             command.Connection = con;
             command.Parameters.AddWithValue("@date", txtAppointmentDate.Text);
             command.Parameters.AddWithValue("@time", ddlAppointmentTime.SelectedValue);
             command.Parameters.AddWithValue("@dept", ddlDepartment.SelectedValue);
             command.Parameters.AddWithValue("@doc", ddlDoctor.SelectedValue);
             command.Parameters.AddWithValue("@did", Ddlid.SelectedValue);
             command.Parameters.AddWithValue("@history", txtHistory.Text);
             command.Parameters.AddWithValue("@patientName", TXTNAME.Text);
             i = Convert.ToInt32(command.ExecuteScalar());
             con.Close();
             string message = string.Empty;
             message = "CONGRATULATIONS, APPOINTMENT BOOKED, PLEASE WAIT FOR CONFIRMATION OF TIME SLOT BY OUR RECEPTIONIST\n APPOINTMENT NUMBER:" + i;
             MessageBox.Show(message);
         }
         catch
         {
             Response.Write("<script>alert('TRY AGAIN');</script>");
         }
    }
    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        int i;
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();   //SqlCommand cmd = new SqlCommand("exec prcAddRecord @id, @name, @city, @did");
        command.CommandText = "forCancelAppointment";

        ////for using stored procedure
        command.CommandType = CommandType.StoredProcedure;   //comment this line too!!!
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@appNum", txtAppNumber.Text);
            i = Convert.ToInt32(command.ExecuteScalar());
            con.Close();
            switch (i)
            {
                case 1:
                    {
                        Response.Write("<script>alert('YOUR APPOINTMENT HAS BEEN CANCELLED');</script>");
                        break;
                    }

                case 2:
                    {
                        Response.Write("<script>alert('YOUR APPOINTMENT NUMBER DOESNOT EXIST');</script>");
                        break;
                    }

                default:
                    {
                        Response.Write("<script>alert('OOPS!SEEMS AN ERROR, SORRY FOR INCONVENIENCE');</script>");
                        break;
                    }

            }
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    
    protected void btnCheckAvailability_Click(object sender, EventArgs e)
    {
        int retVal;
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();   //SqlCommand cmd = new SqlCommand("exec prcAddRecord @id, @name, @city, @did");
        command.CommandText = "checkAvailability";

        ////for using stored procedure
        command.CommandType = CommandType.StoredProcedure;   //comment this line too!!!
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@date", txtAvailDate.Text);
            command.Parameters.AddWithValue("@doc", DDLdOC.SelectedValue);
            retVal = Convert.ToInt32(command.ExecuteScalar());

            con.Close();
            switch (retVal)
            {
                case 1:
                    {
                        Response.Write("<script>alert('DOCTOR ON LEAVE,PLEASE CHOOSE THE NEXT DATE FOR APPOINTMENT');</script>");
                        break;
                    }
                default:
                    {
                        Response.Write("<script>alert('DOCTOR IS AVAILABLE, PLEASE PROCEED WITH THE APPOINTMENT');</script>");
                        break;
                    }

            }
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
}