﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlTypes;
using System.Windows.Forms;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void ButtonMakePay_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void ButtonCheck_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }
    protected void btnSub_Click(object sender, EventArgs e)
    {
        int i;
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();
        command.CommandText = "forCheckingAmtEnteredOutpatient";
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@num", TexAppNum.Text);
            command.Parameters.AddWithValue("@ipamt", TextAmt.Text);
            i = Convert.ToInt32(command.ExecuteScalar());
            con.Close();
            switch (i)
            {
                case 1:
                    {
                        Response.Write("<script>alert('SORRY, YOU HAVE ENTERED WRONG AMOUNT, PLEASE TRY AGAIN');</script>");
                        break;
                    }
                default:
                    {
                        insertAmount();
                        setConfirmationStatusForPayment();
                        break;
                    }
            }
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void insertAmount()
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand cmd = new SqlCommand("update outpatientPayment set iAccountNumber=@iAccNum, vIfscCode=@vIfsc,iPatientsAmount=@ipamt where iAppointmentNumber=@num");

        try
        {
            con.Open();
            cmd.Connection = con;

            cmd.Parameters.AddWithValue("@num", TexAppNum.Text);
            cmd.Parameters.AddWithValue("@iAccNum", TextAccNum.Text);
            cmd.Parameters.AddWithValue("@vIfsc", TextIfsc.Text);
            cmd.Parameters.AddWithValue("@ipamt", TextAmt.Text);

            cmd.ExecuteNonQuery();

            Response.Write("<script>alert('THANKYOU, YOUR PAYMENT HAS BEEN RECEIVED');</script>");
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void setConfirmationStatusForPayment()
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();
        command.CommandText = "confirmOutpatientPay";
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@num", TexAppNum.Text);
            command.ExecuteNonQuery();
            con.Close();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
   
    protected void ButtonChk_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("SELECT vFirstName AS[PATIENT NAME],iPaymentAmount AS [BILL AMOUNT] from outpatientPayment WHERE iAppointmentNumber=@num ", con);
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@num", Textnum.Text);

            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "outpatientPayment");
            GridViewchk.DataSource = ds;
            GridViewchk.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
}