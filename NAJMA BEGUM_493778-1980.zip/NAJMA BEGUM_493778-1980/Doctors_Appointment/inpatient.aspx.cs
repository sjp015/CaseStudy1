﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf.fonts;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DDLName.DataSource = GetData("SELECT vFirstName,vRegistrationRecord FROM inpatientPaymentRecord");
            DDLName.DataTextField = "vFirstName";
            DDLName.DataValueField = "vRegistrationRecord";
            DDLName.DataBind();
        }
    }

    protected void btnGenerateRep_Click(object sender, EventArgs e)
    {
        try
        {
            DataRow dr = GetData("SELECT * FROM inpatientPaymentRecord where vRegistrationRecord=" + DDLName.SelectedItem.Value).Rows[0];
            Document document = new Document(PageSize.A4, 25, 25, 25, 25);
            System.IO.MemoryStream memoryStream = new System.IO.MemoryStream();
            PdfWriter pdfWriter = PdfWriter.GetInstance(document, Response.OutputStream);
            PdfPTable table = null;
            PdfPCell cell = null;
            document.Open();

            Paragraph para = new Paragraph(" ");
            para.SpacingBefore = 20;
            para.SpacingAfter = 20;
            para.Alignment = 1; //'0-Left, 1 middle,2 Right
            document.Add(para);

            table = new PdfPTable(1);
            table.SetWidths(new float[] { 2f });
            table.TotalWidth = 500f;
            table.LockedWidth = true;
            table.SpacingBefore = 20f;
            table.SpacingAfter = 30f;
            table.HorizontalAlignment = Element.ALIGN_CENTER;
            cell = PhraseCell(new Phrase("\nANDHRA PRADESH GENERAL HOSPITAL", FontFactory.GetFont("Arial", 20, BaseColor.BLUE)), PdfPCell.ALIGN_CENTER);
            cell.Colspan = 3;
            cell.PaddingBottom = 30f;
            cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
            cell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
            cell.Colspan = 3;
            table.AddCell(cell);
            document.Add(table);

            Paragraph p = new Paragraph();
            p.Alignment = 1;
            p.Add(new Chunk("NAME : ", FontFactory.GetFont("Arial", 14, Font.BOLD, BaseColor.BLACK)));
            p.Add(new Chunk(dr["vFirstName"].ToString(), FontFactory.GetFont("Arial", 14, BaseColor.BLACK)));
            p.Add(new Chunk("\n\nDISCHARGE DATE :  ", FontFactory.GetFont("Arial", 14, Font.BOLD, BaseColor.BLACK)));
            p.Add(new Chunk(dr["dDischargeDate"].ToString(), FontFactory.GetFont("Arial", 14, BaseColor.BLACK)));
            p.Add(new Chunk("\n\nBILL AMOUNT  :  ", FontFactory.GetFont("Arial", 14, Font.BOLD, BaseColor.BLACK)));
            p.Add(new Chunk(dr["iPaymentAmount"].ToString(), FontFactory.GetFont("Arial", 14, BaseColor.BLACK)));
            p.Add(new Chunk("\n\nRECEPTIONIST ID  :  ", FontFactory.GetFont("Arial", 14, Font.BOLD, BaseColor.BLACK)));
            p.Add(new Chunk(dr["iReceptionId"].ToString(), FontFactory.GetFont("Arial", 14, BaseColor.BLACK)));
            p.Add(new Chunk("\n\nAMOUNT PAID  :  ", FontFactory.GetFont("Arial", 14, Font.BOLD, BaseColor.BLACK)));
            p.Add(new Chunk(dr["iPatientsAmount"].ToString(), FontFactory.GetFont("Arial", 14, BaseColor.BLACK)));
            p.Add(new Chunk("\n\nACCOUNT NUMBER  :  ", FontFactory.GetFont("Arial", 14, Font.BOLD, BaseColor.BLACK)));
            p.Add(new Chunk(dr["iAccountNumber"].ToString(), FontFactory.GetFont("Arial", 14, BaseColor.BLACK)));


            document.Add(p);

            PdfContentByte content = pdfWriter.DirectContent;
            iTextSharp.text.Rectangle rectangle = new iTextSharp.text.Rectangle(document.PageSize);
            rectangle.Left += document.LeftMargin;
            rectangle.Right -= document.RightMargin;
            rectangle.Top -= document.TopMargin;
            rectangle.Bottom += document.BottomMargin;
            content.SetColorStroke(iTextSharp.text.BaseColor.RED);
            content.Rectangle(rectangle.Left, rectangle.Bottom, rectangle.Width, rectangle.Height);
            content.Rectangle(rectangle.Left, rectangle.Bottom, rectangle.Width, rectangle.Height);
            content.Stroke();

            pdfWriter.CloseStream = false;
            document.Close();
            Response.Buffer = true;
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=InpatientReceipt.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Write(document);
            Response.End();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    private DataTable GetData(string query)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand cmd = new SqlCommand(query);
        using (SqlDataAdapter da = new SqlDataAdapter())
        {
            cmd.Connection = con;
            con.Open();
            da.SelectCommand = cmd;
            using (DataTable dt = new DataTable())
            {
                da.Fill(dt);
                return dt;
            }
        }
    }
    private static PdfPCell PhraseCell(Phrase phrase, int align)
    {
        PdfPCell cell = new PdfPCell(phrase);
        cell.BorderColor = BaseColor.BLACK;
        cell.VerticalAlignment = PdfPCell.ALIGN_TOP;
        cell.HorizontalAlignment = align;
        cell.PaddingBottom = 2f;
        cell.PaddingTop = 2f;
        return cell;
    }
}