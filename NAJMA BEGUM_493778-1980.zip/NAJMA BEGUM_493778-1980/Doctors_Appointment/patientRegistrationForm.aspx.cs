﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Data.SqlTypes;

public partial class patientRegistrationForm : System.Web.UI.Page
{
    
     protected void Page_Load(object sender, EventArgs e)
    {
        
    }
   

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int choice;
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();

          command.CommandText = "checkDoctorAvailability";
        command.CommandType = CommandType.StoredProcedure;  

        
            command.CommandText = "forOutpatientBooking";
            
            ////for using stored procedure
             command.CommandType = CommandType.StoredProcedure;
             try
             {
                 con.Open();
                 command.Connection = con;

                 command.Parameters.AddWithValue("@firstname", txtFirstName.Text);
                 command.Parameters.AddWithValue("@lastname", txtLastName.Text);
                 command.Parameters.AddWithValue("@age", txtAge.Text);
                 command.Parameters.AddWithValue("@gender", RadioButtonList1.SelectedValue);
                 command.Parameters.AddWithValue("@appNum", generateAppointmentNumber());
                 command.Parameters.AddWithValue("@email", txtEmailID.Text);
                 command.Parameters.AddWithValue("@phone", txtContactNo.Text);
                 command.Parameters.AddWithValue("@appdate", txtAppointmentDate.Text);
                 command.Parameters.AddWithValue("@apptime", ddlAppointmentTime.SelectedValue);
                 command.Parameters.AddWithValue("@dept", ddlDepartment.SelectedValue);
                 command.Parameters.AddWithValue("@doc", ddlDoctor.SelectedValue);

                 command.ExecuteNonQuery();
             }
             catch
             {
                 Response.Write("<script>alert('TRY AGAIN');</script>");
             }
    }

    public string generateID()
    {
        Guid g = Guid.NewGuid();
        string random = g.ToString();
        string id = random.Substring(0, 8);
        return id;
    }
    public int generateAppointmentNumber()
    {
        Random random = new Random();
        return random.Next(1, 200);
      }
}