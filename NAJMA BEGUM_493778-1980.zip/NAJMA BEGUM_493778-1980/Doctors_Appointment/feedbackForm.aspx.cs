﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

public partial class feedbackForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();
        command.CommandText = "forFeedback";

        ////for using stored procedure
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;

            command.Parameters.AddWithValue("@like", RadioButtonList1.SelectedValue);
            command.Parameters.AddWithValue("@hosEnvi", RadioButtonList2.SelectedValue);
            command.Parameters.AddWithValue("@wardFci", RadioButtonList3.SelectedValue);
            command.Parameters.AddWithValue("@docService", RadioButtonList4.SelectedValue);
            command.Parameters.AddWithValue("@nurseService", RadioButtonList5.SelectedValue);
            command.Parameters.AddWithValue("@billing", RadioButtonList6.SelectedValue);
            command.Parameters.AddWithValue("@admission", RadioButtonList7.SelectedValue);
            command.Parameters.AddWithValue("@overallexp", RadioButtonList8.SelectedValue);
            command.Parameters.AddWithValue("@sugg", txtSuggestionBox.Text);

            command.ExecuteNonQuery();
            Response.Write("<script>alert('THANKYOU FOR YOUR FEEDBACK :)');</script>");
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
}