﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();
        command.CommandText = "addDoctor";
        command.CommandType = CommandType.StoredProcedure;

        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@id", txtid.Text);
            command.Parameters.AddWithValue("@name", txtName.Text);
            command.Parameters.AddWithValue("@qua", txtQualification.Text);
            command.Parameters.AddWithValue("@depname", DDLDEPNAMELIST.SelectedValue);
            command.Parameters.AddWithValue("@depid", DDLID.SelectedValue);
            command.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('DOCTOR SUCCESSFULLY ADDED TO DEPARTMENT');</script>");
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();
        command.CommandText = "addReceptionist";
        command.CommandType = CommandType.StoredProcedure;

        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@id", txtIdd.Text);
            command.Parameters.AddWithValue("@name", txtNamme.Text);
            command.Parameters.AddWithValue("@pwd", txtpwd.Text);

            command.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('RECEPTIONIST SUCCESSFULLY ADDED');</script>");
        }
        catch(Exception ex)
        {
            Response.Write("<script>alert('ALREADY EXISTS');</script>");
           
            
        }
        Response.Redirect("AdminAddStaff.aspx");
    }
}