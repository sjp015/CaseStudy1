﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class bookAmbulance : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnBook_Click(object sender, EventArgs e)
    {
        
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();
        command.CommandText = "bookAmbulance";

        ////for using stored procedure
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;

            command.Parameters.AddWithValue("@fname", txtFirstName.Text);
            command.Parameters.AddWithValue("@lname", txtLastName.Text);
            command.Parameters.AddWithValue("@age", txtAge.Text);
            command.Parameters.AddWithValue("@pickdate", txtPickUpDate.Text);
            command.Parameters.AddWithValue("@picktime", ddlTime.SelectedValue);
            command.Parameters.AddWithValue("@location", txtPickUpLocation.Text);
            command.Parameters.AddWithValue("@condition", txtCondition.Text);
            command.Parameters.AddWithValue("@clinicalreq", tbClinicalReq.Text);
            command.Parameters.AddWithValue("@otherclinicalreq", txtClinicalRequirements.Text);
            command.Parameters.AddWithValue("@infection", rblInfection.SelectedValue);
            command.Parameters.AddWithValue("@infectionType", txtInfections.Text);
            command.Parameters.AddWithValue("@transportReq", tbTransportReq.Text);
            command.Parameters.AddWithValue("@details", txtRelevantDetails.Text);
            command.ExecuteNonQuery();
            Response.Write("<script>alert('AMBULANCE IS BOOKED');</script>");
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
}