﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

public partial class PatientLoginForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void RadioButton1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if(rblForPatientLogin.SelectedValue=="INPATIENT")
        {
            MultiView1.ActiveViewIndex = 0;
        }
        else if (rblForPatientLogin.SelectedValue=="OUTPATIENT")
        {
            MultiView1.ActiveViewIndex = 1;
        }
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand com = new SqlCommand("inpatienLoginvalidate", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@name", txtName.Text);
        com.Parameters.AddWithValue("@rid", txtRegistrationNum.Text);

        con.Open();
        SqlDataReader rd = com.ExecuteReader();
        if (rd.HasRows)
        {
            rd.Read();
            Label1.Text = "Login successful.";
            Session["username"] = txtName.Text;
            Response.Redirect("inpatient.aspx");

        }

        else
        {
            Label1.Text = "Invalid username or password.";

        }
    }
}