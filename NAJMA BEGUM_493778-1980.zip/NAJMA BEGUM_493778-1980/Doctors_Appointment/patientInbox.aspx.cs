﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("select iAppointmentNumber as[APPOINTMENT NUMBER], vPatientName as[ PATIENT NAME], cConfirmation AS [CONFIRMATION STATUS], iReceptionisId as [APPROVED BY RECEPTIONIST] from outpatientAppointments where iAppointmentNumber=@num", con);
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@num", TextAppnum.Text);
            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "outpatientAppointments");
            gvAppStatus.DataSource = ds;
            gvAppStatus.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
}