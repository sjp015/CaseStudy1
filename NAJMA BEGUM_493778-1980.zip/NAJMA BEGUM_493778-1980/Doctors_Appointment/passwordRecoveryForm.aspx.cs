﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Windows.Forms;

public partial class passwordRecoveryForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void btnRecover_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        int retval;
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();   //SqlCommand cmd = new SqlCommand("exec prcAddRecord @id, @name, @city, @did");
        command.CommandText = "passwordRecoveryDoctor1";

        ////for using stored procedure
        command.CommandType = CommandType.StoredProcedure;   //comment this line too!!!
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@username", txtUserName.Text);
            command.Parameters.AddWithValue("@q1", txtq1.Text);
            command.Parameters.AddWithValue("@q2", txtq2.Text);
            command.Parameters.AddWithValue("@q3", txtq3.Text);
            retval = Convert.ToInt32(command.ExecuteScalar());

            con.Close();
            switch (retval)
            {
                case 1:
                    {
                        MultiView1.ActiveViewIndex = 1;
                        break;
                    }
                default:
                    {
                        Response.Write("<script>alert('WRONG DATA');</script>");
                        break;
                    }

            }
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void btnSub_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();   //SqlCommand cmd = new SqlCommand("exec prcAddRecord @id, @name, @city, @did");
        command.CommandText = "passRecoveryDoctor";

        ////for using stored procedure
        command.CommandType = CommandType.StoredProcedure;   //comment this line too!!!
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@username", Textuser.Text);
            command.Parameters.AddWithValue("@pwd", Textpwd.Text);
            command.ExecuteNonQuery();
            Response.Write("<script>alert('YOUR NEW PASSWORD SAVED');</script>");
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
}