﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Data.SqlTypes;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnCheckAppointment_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void btnCheckHistory_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string sta = "YES";
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("select  vPatientName AS [PAIENT NAME],iAppointmentNumber AS [APPOINTMENT NUMBER] from outpatientAppointments  where dAppointmentDate=@date and vDoctorName=@name and cConfirmation=@status", con);
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@date", txtDate.Text);
            command.Parameters.AddWithValue("@name", ddlDoctor.SelectedValue);
            command.Parameters.AddWithValue("@status", sta);
            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "outpatientAppointments");
            gvViewAllAppointment.DataSource = ds;
            gvViewAllAppointment.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
        
    }
    
    protected void btnInpatient_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;
        
    }
    protected void btnOutpatient_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 3;
    }

    protected void btnHistory_Click1(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("select vPatientHistory from outpatientAppointments where vDoctorName=@name", con);
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@name", ddlDoctorHistory.SelectedValue);
            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "outpatientAppointments");
            gvViewPatientHistory.DataSource = ds;
            gvViewPatientHistory.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }

    
}