﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Session["username"]!=null)
        {
            recepId.Text = Session["username"].ToString();
        }
    }
    protected void btnAttendance_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void btnPatientApp_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }

    protected void btnAdmit_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;
    }
    protected void btnInpatient_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 3;
    }
    protected void btnPaymentOK_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 4;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("SELECT COUNT(*) AS [NUMBER OF LEAVES], vDoctorName AS [DOCTOR NAME] from doctorLeave WHERE vDoctorName=@name GROUP BY vDoctorName", con);
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@name", ddlName.SelectedValue);
            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "doctorLeave");
            gvDoctor.DataSource = ds;
            gvDoctor.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void btnCheck_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("select vPatientName AS[PATIENT NAME],dAppointmentDate AS [APPOINTMENT DATE],tAppointmentTime AS [APPOINTMENT TIME],vDepartment AS [DEPARTMENT NAME],vDoctorName AS[DOCTOR NAME],iAppointmentNumber AS [APPOINTMENT NUMBER] FROM outpatientAppointments WHERE dAppointmentDate=@date  ", con);
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@date", txtDate.Text);
            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "outpatientAppointments");
            gvViewAllAppointment.DataSource = ds;
            gvViewAllAppointment.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }

    protected void btnDischargePatient_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();


        command.CommandType = CommandType.StoredProcedure;


        command.CommandText = "forInpatientDischarge";

        ////for using stored procedure
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;

            command.Parameters.AddWithValue("@firstname", ddlGetName.SelectedValue);
            command.Parameters.AddWithValue("@payment", txtPaymentAmt.Text);
            command.Parameters.AddWithValue("@dischargeDate", txtDischargeDate.Text);
            command.Parameters.AddWithValue("@receptionId", txtGetReceptionId.Text);
            command.ExecuteNonQuery();
            Response.Write("<script>alert('PATIENT DISCHARGE SUCCESSFUL');</script>");
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }


    protected void btnCheckNumber_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("select  iCurrentStrength AS [CURRENT STRENGTH],iVacancy AS [VACANCY] from trackInpatientNumber  where vWardType=@ward", con);
        try
        {
            con.Open();
            command.Parameters.AddWithValue("@ward", ddlWardList.SelectedValue);
            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "trackInpatientNumber");
            inpatientData.DataSource = ds;
            inpatientData.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    
    protected void btSub_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();


        command.CommandType = CommandType.StoredProcedure;


        command.CommandText = "statusApproval";

        ////for using stored procedure
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;
            command.Parameters.AddWithValue("@num", txtAppNum.Text);
            command.Parameters.AddWithValue("@status", txtStatus.Text);
            command.Parameters.AddWithValue("@recepid", recepId.Text);
            command.ExecuteNonQuery();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }


    protected void ButtonInpatient_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 5;
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("SELECT  vFirstName as [PATIENT NAME],iPaymentAmount AS [BILL AMOUNT], dDischargeDate AS[DISCHARGE DATE], iPatientsAmount AS [AMOUNT PAID], cConfirmation AS[CONFIRMATION STATUS] FROM inpatientPaymentRecord  ", con);
        try
        {
            con.Open();
            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "inpatientPaymentRecord");
            GgvInpatientPayStatus.DataSource = ds;
            GgvInpatientPayStatus.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void ButtonOutpatient_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 5;
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        SqlCommand command = new SqlCommand("SELECT  vFirstName as [PATIENT NAME],iAppointmentNumber as[APPOINTMENT NUMBER],iPaymentAmount AS [BILL AMOUNT], dAppointmentDate AS[DISCHARGE DATE], iPatientsAmount AS [AMOUNT PAID], cConfirmation AS[CONFIRMATION STATUS] FROM outpatientPayment  ", con);
        try
        {
            con.Open();
            da.SelectCommand = command;
            da.SelectCommand.ExecuteNonQuery();
            da.Fill(ds, "outpatientPayment");
            GgvInpatientPayStatus.DataSource = ds;
            GgvInpatientPayStatus.DataBind();
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
    protected void ButtonOutpay_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 6;


    }

    protected void ButtonSUB_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12815\SQLEXPRESS;Database=dbOnlineDoctorAppointment;Integrated Security= false;uid=SA;pwd=System123");
        SqlCommand command = new SqlCommand();


        command.CommandType = CommandType.StoredProcedure;


        command.CommandText = "forPaymentDetails";

        ////for using stored procedure
        command.CommandType = CommandType.StoredProcedure;
        try
        {
            con.Open();
            command.Connection = con;

            command.Parameters.AddWithValue("@num", TextAPP.Text);
            command.Parameters.AddWithValue("@amt", Textamt.Text);
            command.Parameters.AddWithValue("@id", recepId.Text);
            command.ExecuteNonQuery();
            Response.Write("<script>alert('PAYMENT DETAILS UPDATED');</script>");
        }
        catch
        {
            Response.Write("<script>alert('TRY AGAIN');</script>");
        }
    }
   
}