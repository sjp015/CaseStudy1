﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Configuration;

namespace TransactIt
{
    public partial class frmBankDetails : System.Web.UI.Page
    {
        string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["IFScode"] == null)
                Response.Redirect("frmLogin.aspx");

            Session.Timeout = 8;

            string IFScode = Session["IFScode"].ToString();
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("uspGetBankName @IFScode", con);
            cmd.Parameters.AddWithValue("@IFScode", IFScode);
            try
            {
                lblName.Text = cmd.ExecuteScalar().ToString();
                lblIFSC.Text = IFScode;
            }
            catch(Exception)
            {

            }
            finally
            {
                con.Close();
            }
            if(!Page.IsPostBack)
            {
                MultiView1.ActiveViewIndex = 0;
                LinkButton1.ForeColor = Color.White;
                BankDetails();
            }
        }

        protected void lbtLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("frmLogin.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            BankDetails();
        }

        private void BankDetails()
        {
            MultiView1.ActiveViewIndex = 0;
            LinkButton1.ForeColor = Color.White;
            LinkButton2.ForeColor = Color.Gray;
            LinkButton3.ForeColor = Color.Gray;
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string IFScode = Session["IFScode"].ToString();
            SqlCommand cmd = new SqlCommand("uspGetBankDetails @IFScode", con);
            cmd.Parameters.AddWithValue("@IFScode", IFScode);

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            gdvGeneralDetails.DataSource = dt;
            gdvGeneralDetails.DataBind();

            con.Close();
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 1;
            LinkButton1.ForeColor = Color.Gray;
            LinkButton2.ForeColor = Color.White;
            LinkButton3.ForeColor = Color.Gray;

            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string IFScode = Session["IFScode"].ToString();
            SqlCommand cmd = new SqlCommand("uspGetCustomersInBank @IFScode", con);
            cmd.Parameters.AddWithValue("@IFScode", IFScode);

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            gdvAccountHolders.DataSource = dt;
            gdvAccountHolders.DataBind();

            con.Close();
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 2;
            LinkButton1.ForeColor = Color.Gray;
            LinkButton2.ForeColor = Color.Gray;
            LinkButton3.ForeColor = Color.White;

            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string IFScode = Session["IFScode"].ToString();
            SqlCommand cmd = new SqlCommand("uspGetBankTrans @IFScode", con);
            cmd.Parameters.AddWithValue("@IFScode", IFScode);

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            gdvTransaction.DataSource = dt;
            gdvTransaction.DataBind();
            con.Close();

            con.Open();
            SqlCommand cmd1 = new SqlCommand("uspGetBankTransInbound @IFScode", con);
            cmd1.Parameters.AddWithValue("@IFScode", IFScode);

            SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            sda1.Fill(dt1);
            gdvInboundTran.DataSource = dt1;
            gdvInboundTran.DataBind();
        }

        protected void btnRefreshGeneralDetails_Click(object sender, EventArgs e)
        {
            
        }

        protected void btnRefreshAccountHolders_Click(object sender, EventArgs e)
        {
            
        }

        protected void btnRefreshTransaction_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string IFScode = Session["IFScode"].ToString();
            SqlCommand cmd = new SqlCommand("uspGetTransactions @IFScode", con);
            cmd.Parameters.AddWithValue("@IFScode", IFScode);

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            gdvTransaction.DataSource = dt;
            gdvTransaction.DataBind();

            con.Close();
        }

        
    }
}