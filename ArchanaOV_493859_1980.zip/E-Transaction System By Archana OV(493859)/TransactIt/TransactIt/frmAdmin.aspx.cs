﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Configuration;

namespace TransactIt
{
    public partial class frmAdmin : System.Web.UI.Page
    {
        string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["id"] == null)
                Response.Redirect("frmLogin.aspx");
        }

        protected void lbtLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("frmLogin.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
            LinkButton1.ForeColor = Color.Blue;
            LinkButton2.ForeColor = Color.Gray;

            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            SqlCommand cmd = new SqlCommand("uspGetAllCustomers", con);
            gdvCustomers.DataSource = cmd.ExecuteReader();
            gdvCustomers.DataBind();
            con.Close();
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 1;
            LinkButton1.ForeColor = Color.Gray;
            LinkButton2.ForeColor = Color.Blue;
            
            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            SqlCommand cmd = new SqlCommand("uspGetAllBanks", con);
            gdvBanks.DataSource = cmd.ExecuteReader();
            gdvBanks.DataBind();
            con.Close();
        }
    }
}