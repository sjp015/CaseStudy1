﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Configuration;

namespace TransactIt
{
    public partial class frmRecoverPassword : System.Web.UI.Page
    {
        string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            SqlCommand cmd = new SqlCommand("uspFetchQuestion @loginId", con);
            cmd.Parameters.AddWithValue("@loginId",txtLoginID.Text);

            object question = cmd.ExecuteScalar();
            if ( question!= null)
            {
                MultiView1.ActiveViewIndex = 0;
                lblQuestion.Text = (string)question;
            }
            else
            {
                Label1.Text = "This Login ID doesn't exist";
            }

            con.Close();
                
            
        }

        protected void btnVerify_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            SqlCommand cmd = new SqlCommand("uspGetAnswer @loginId", con);
            cmd.Parameters.AddWithValue("@loginId", txtLoginID.Text);
            string answer = (string)cmd.ExecuteScalar();
            if(txtAnswer.Text.Equals(answer))
            {
                MultiView2.ActiveViewIndex = 0;
            }
            else
            {
                Label2.Text = "Sorry! Your answer doesn't match with the answer you provided during registration";
            }
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            SqlCommand cmd = new SqlCommand("uspUpdatePassword @loginId, @Password", con);
            cmd.Parameters.AddWithValue("@loginId", txtLoginID.Text);
            cmd.Parameters.AddWithValue("@Password", txtNewPassword.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Your password is changed successfully");
            Response.Redirect("frmLogin.aspx");
            con.Close();
        }
    }
}