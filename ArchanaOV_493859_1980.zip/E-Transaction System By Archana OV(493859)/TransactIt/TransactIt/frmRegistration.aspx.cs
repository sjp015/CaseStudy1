﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace TransactIt
{
    public partial class frmRegistration : System.Web.UI.Page
    {
        string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                MultiView1.ActiveViewIndex = 0;
                LinkButton1.ForeColor = Color.Blue;
            }
            //rvDate.MaximumValue = DateTime.Today.ToString("yyyy-MM-dd");
            txtBirthday.Attributes["max"] = DateTime.Now.AddYears(-10).ToString("yyyy-MM-dd");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
            LinkButton1.ForeColor = Color.Blue;
            LinkButton2.ForeColor = Color.Gray;
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 1;
            LinkButton2.ForeColor = Color.Blue;
            LinkButton1.ForeColor = Color.Gray;
        }

        protected void btnUserSubmit_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            string loginId = "cust" + rnd.Next(1,999999);
            string pwdString = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string password = "";
            for(int i = 0;i<=7;i++)
            {
                int random = rnd.Next(5, pwdString.Length - 1);
                password += pwdString.Substring(random, 1);
            }
            SqlConnection conUser = new SqlConnection(conStr);
            conUser.Open();

            SqlCommand cmd = new SqlCommand("Insert into tblCustomerDetails values(@CustomerLoginId,@CustomerPassword,@CustomerName,@Email,@Usertype,@DOB,@Gender,@Locality,@City,@PinCode,@CustomerState,@PhoneNumber,@IsActive)", conUser);
            cmd.Parameters.AddWithValue("@CustomerloginId", loginId);
            cmd.Parameters.AddWithValue("@CustomerPassword", password);
            cmd.Parameters.AddWithValue("@CustomerName", txtName.Text);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@UserType", rblUserType.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@DOB", txtBirthday.Text);
            cmd.Parameters.AddWithValue("@Gender", rblGender.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@Locality", txtLocality.Text);
            cmd.Parameters.AddWithValue("@City", txtCity.Text);
            cmd.Parameters.AddWithValue("@PinCode", txtPinCode.Text);
            cmd.Parameters.AddWithValue("@CustomerState", txtState.Text);
            cmd.Parameters.AddWithValue("@PhoneNumber", txtPhone.Text);
            cmd.Parameters.AddWithValue("@IsActive", "Yes");
            try
            {
                if (Page.IsValid)
                {
                    cmd.ExecuteNonQuery();
                    Session["id"] = loginId;
                    Response.Redirect("frmSecurityQuestion.aspx");
                }
            }
            catch (Exception)
            {
                Literal1.Text = "<span style='color:red'>Registration failed</span>";
            }
            finally
            {
                txtName.Text = string.Empty;
                txtEmail.Text = string.Empty;
                txtBirthday.Text = string.Empty;
                txtLocality.Text = string.Empty;
                txtCity.Text = string.Empty;
                txtPinCode.Text = string.Empty;
                txtState.Text = string.Empty;
                rblGender.SelectedIndex = -1;
                rblUserType.SelectedIndex = -1;
                txtPhone.Text = string.Empty;
                conUser.Close();
            }
        }


        protected void btnBankSubmit_Click(object sender, EventArgs e)
        {
            SqlConnection conBank = new SqlConnection(conStr);
            conBank.Open();

            SqlCommand cmd = new SqlCommand("Insert into tblBankDetails values(@IFSCode,@BankName,@BankLocality,@BankCity,@BankState,@BankPassword,@AccountStatus)",conBank);
            cmd.Parameters.AddWithValue("@IFSCode", txtIFSCode.Text);
            cmd.Parameters.AddWithValue("@BankName", txtBankName.Text);
            cmd.Parameters.AddWithValue("@BankLocality", txtBankLocality.Text);
            cmd.Parameters.AddWithValue("@BankCity", txtBankCity.Text);
            cmd.Parameters.AddWithValue("@BankState", txtBankState.Text);
            cmd.Parameters.AddWithValue("@BankPassword", txtBankPassword.Text);
            cmd.Parameters.AddWithValue("@AccountStatus", "Active");
            try
            {
                cmd.ExecuteNonQuery();
                Literal2.Text = "<span style='color:green'>Registration successful</span>";
                
            }
            catch(Exception)
            {
                Literal2.Text = "<span style='color:red'>This IFSCode already exists, please try a different one</span>";
            }
            finally
            {
                txtBankName.Text = string.Empty;
                txtBankLocality.Text = string.Empty;
                txtBankCity.Text = string.Empty;
                txtIFSCode.Text = string.Empty;
                txtBankState.Text = string.Empty;
                conBank.Close();
            }
        }
    }
}