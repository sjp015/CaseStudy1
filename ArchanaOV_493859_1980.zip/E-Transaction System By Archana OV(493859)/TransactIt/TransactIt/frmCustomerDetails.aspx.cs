﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Configuration;

namespace TransactIt
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["CustomerLoginId"] == null)
                Response.Redirect("frmLogin.aspx");

            Session.Timeout = 8;

            if(!Page.IsPostBack)
            {
                MultiView1.ActiveViewIndex = 0;
                LinkButton1.ForeColor = Color.White;
                PersonalDetails();
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            PersonalDetails();
        }

        private void PersonalDetails()
        {
            MultiView1.ActiveViewIndex = 0;
            LinkButton1.ForeColor = Color.White;
            LinkButton2.ForeColor = Color.Gray;
            LinkButton3.ForeColor = Color.Gray;

            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string loginId = Session["CustomerLoginId"].ToString();
            SqlCommand cmd = new SqlCommand("uspGetPersonalDetails @CustomerLoginId", con);
            cmd.Parameters.AddWithValue("@CustomerLoginId", loginId);
            gdvPersonal.DataSource = cmd.ExecuteReader();
            gdvPersonal.DataBind();
            con.Close();
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 1;
            LinkButton1.ForeColor = Color.Gray;
            LinkButton2.ForeColor = Color.White;
            LinkButton3.ForeColor = Color.Gray;
            
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string loginId = Session["CustomerLoginId"].ToString();
            SqlCommand cmd = new SqlCommand("uspGetBankingDetails @CustomerLoginId", con);
            cmd.Parameters.AddWithValue("@CustomerLoginId", loginId);
            gdvBanking.DataSource = cmd.ExecuteReader();
            gdvBanking.DataBind();
            con.Close();
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 2;
            LinkButton1.ForeColor = Color.Gray;
            LinkButton2.ForeColor = Color.Gray;
            LinkButton3.ForeColor = Color.White;
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            string loginId = Session["CustomerLoginId"].ToString();
            SqlCommand cmd = new SqlCommand(@"uspAuthenticateCustomer @CustomerLoginId", con);
            cmd.Parameters.AddWithValue("@CustomerLoginId", loginId);
            try
            {
                string pass = (string)cmd.ExecuteScalar();
                if (txtOldPassword.Text.Equals(pass))
                {
                    con.Close();
                    con.Open();
                    SqlCommand cmd1 = new SqlCommand("uspUpdatePassword @loginId, @Password", con);
                    cmd1.Parameters.AddWithValue("@loginId", loginId);
                    cmd1.Parameters.AddWithValue("@Password", txtNewPassword.Text);
                    cmd1.ExecuteNonQuery();
                    litMessage.Text = "<span style='color:green'>Your password is changed</span>";
                    con.Close();
                }
                else
                {
                    litMessage.Text = "<span style='color:red'>Your old password is incorrect</span>";
                }
            }
            catch (Exception)
            {
                litMessage.Text = "<span style='Yellow'>Oops! seems like some error occured, Please retry a bit later</span>";
            }
        }
    }
}