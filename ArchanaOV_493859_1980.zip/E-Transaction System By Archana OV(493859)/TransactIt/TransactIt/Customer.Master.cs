﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Drawing;
using System.Web.UI.WebControls;

namespace TransactIt
{
    
    public partial class Customer : System.Web.UI.MasterPage
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            LinkButton2.ForeColor = Color.Blue;
            LinkButton1.ForeColor = Color.Gray;
            Response.Redirect("frmCustomerDetails.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            LinkButton1.ForeColor = Color.Blue;
            LinkButton2.ForeColor = Color.Gray;
            Response.Redirect("frmTransaction.aspx");
        }

        protected void lbtLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("frmLogin.aspx");
        }
    }
}