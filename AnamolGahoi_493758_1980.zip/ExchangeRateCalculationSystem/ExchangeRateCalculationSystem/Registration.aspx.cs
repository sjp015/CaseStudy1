﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Data;

public partial class Registration : System.Web.UI.Page
{
    //public String characters = "abcdeCDEfghijkzMABFHIJKLNOlmnopqrPQRSTstuvwxyUVWXYZ";

    

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {


        SqlConnection con = new SqlConnection(@"Server=INBASDPC12535;Database=project;Integrated Security=false");
        SqlCommand cmd = new SqlCommand();
        cmd = new SqlCommand("prcInsertEmpDetails", con); 

        cmd.CommandType = CommandType.StoredProcedure;

        con.Open();
        cmd.Parameters.Add("@empName", TextBox1.Text);
        cmd.Parameters.Add("@compName", TextBox2.Text);
        cmd.Parameters.Add("@address", TextBox3.Text);
        cmd.Parameters.Add("@contact_no", TextBox4.Text);
        cmd.Parameters.Add("@email", TextBox5.Text);
        cmd.Parameters.Add("@bank_acc_no", TextBox6.Text);
        
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("HomePage.aspx");
        //Session["id"] = Label2.Text;
        //Session["name"] = TextBox1.Text;
        //try
        //{
        //    Response.Redirect("HomePage.aspx");
        //}
        //catch
        //{

        //    Label2.Text = "Please Enter correct details.....";
        //    this.Label2.ForeColor = Color.Red;

        //}
    }
}