﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace TransactIt
{
    public partial class frmShowPassword : System.Web.UI.Page
    {
        string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["id"] == null)
                Response.Redirect("frmLoginPage.aspx");

            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            string loginId = Session["id"].ToString();
            SqlCommand cmd = new SqlCommand(@"uspAuthenticateCustomer @CustomerLoginId", con);
            cmd.Parameters.AddWithValue("@CustomerLoginId", loginId);

            lblLogin.Text = "Your Login Id Is: " + loginId;
            lblPassword.Text = "Your Password Is: " + cmd.ExecuteScalar();

            con.Close();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("frmLogin.aspx");
        }
    }
}