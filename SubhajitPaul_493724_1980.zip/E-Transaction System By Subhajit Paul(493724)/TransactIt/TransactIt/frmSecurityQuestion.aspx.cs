﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace TransactIt
{
    public partial class frmSecurityQuestion : System.Web.UI.Page
    {
        string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["id"] == null)
                Response.Redirect("frmLoginPage.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            string loginId = Session["id"].ToString();
            SqlCommand cmd = new SqlCommand("uspSetSecurityQuestion @id, @sq, @ans", con);
            cmd.Parameters.AddWithValue("@id", loginId);
            cmd.Parameters.AddWithValue("@sq", ddlQuestion.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@ans", txtAnswer.Text);
            try
            {
                cmd.ExecuteNonQuery();
                Response.Redirect("frmShowPassword.aspx");
            }
            catch(Exception)
            {
                lblErrorMessage.Text = "Couldn't set security question";
            }
            finally
            {
                con.Close();
            }
        }
    }
}