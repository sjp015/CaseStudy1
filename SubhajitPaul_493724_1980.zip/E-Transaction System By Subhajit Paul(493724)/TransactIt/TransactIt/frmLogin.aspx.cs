﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace TransactIt
{
    public partial class frmLogin : System.Web.UI.Page
    {
        string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string type = txtLoginIDIfsc.Text.Substring(0,4);
            if(type.Equals("cust"))
            {
                SqlCommand cmd = new SqlCommand(@"uspAuthenticateCustomer @CustomerLoginId",con);
                cmd.Parameters.AddWithValue("@CustomerLoginId", txtLoginIDIfsc.Text);
                try
                {
                    string pass = (string)cmd.ExecuteScalar();
                    if (txtPassword.Text.Equals(pass))
                    {
                        Session["CustomerLoginId"] = txtLoginIDIfsc.Text;
                        Response.Redirect("frmTransaction.aspx");
                    }
                    else
                    {
                        litMessage.Text = "<span style='color:red'>Sorry! seems like your Login Id/IFS Code or Password is incorrect or your account is inactive</span>";
                    }
                }
                catch (Exception)
                {
                    litMessage.Text = "<span style='Yellow'>Oops! seems like some error occured, Please retry a bit later</span>";
                }
            }
            else if(txtLoginIDIfsc.Text.Equals("admin@etran") && txtPassword.Text.Equals("Admin123"))
            {
                Session["id"] = txtLoginIDIfsc.Text;
                Response.Redirect("frmAdmin.aspx");
            }
            else
            {
                SqlCommand cmd = new SqlCommand(@"uspAuthenticateBank @IFScode", con);
                cmd.Parameters.AddWithValue("@IFScode", txtLoginIDIfsc.Text);
                try
                {
                    string pass = (string)cmd.ExecuteScalar();
                    if (txtPassword.Text.Equals(pass))
                    {
                        Session["IFScode"] = txtLoginIDIfsc.Text;
                        Response.Redirect("frmBankDetails.aspx");
                    }
                    else
                    {
                        litMessage.Text = "<span style='color:red'>Sorry! seems like your Login Id/IFS Code or Password is incorrect or your account is inactive</span>";
                    }
                }
                catch (Exception)
                {
                    litMessage.Text = "<span style='Yellow'>Oops! seems like some error occured, Please retry a bit later</span>";
                }
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {

        }
    }
}