﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System.Configuration;

namespace TransactIt
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        string conStr = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            SessionValidation();

            string loginId = Session["CustomerLoginId"].ToString();
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("uspGetCustomerName @CustomerLoginId", con);
            cmd.Parameters.AddWithValue("@CustomerLoginId", loginId);
            lblCustomerName.Text = "Hi " + cmd.ExecuteScalar()+"!";
            if (!Page.IsPostBack)
            {
                MultiView1.ActiveViewIndex = 3;
                LinkButton4.ForeColor = Color.White;
                try
                {
                    SqlCommand cmd1 = new SqlCommand("Select BankName from tblBankDetails", con);
                    ddlPayeeBank.DataSource = cmd1.ExecuteReader();
                    ddlAccBankName.DataSource = ddlPayeeBank.DataSource;
                    ddlPayeeBank.DataTextField = "BankName";
                    ddlAccBankName.DataTextField = "BankName";
                    ddlPayeeBank.DataBind();
                    ddlAccBankName.DataBind();
                    ddlPayeeBank.Items.Insert(0, new ListItem("", "0"));
                    ddlAccBankName.Items.Insert(0, new ListItem("", "0"));
                }
                catch (Exception)
                {
                    
                }
                finally
                {
                    con.Close();
                }
            }   
            
        }

        public void SessionValidation()
        {
            if (Session["CustomerLoginId"] == null)
                Response.Redirect("frmLogin.aspx");

            Session.Timeout = 8;
        }

        

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
            lblTranBalance.Text = string.Empty;
            LinkButton1.ForeColor = Color.White;
            LinkButton2.ForeColor = Color.Gray;
            LinkButton3.ForeColor = Color.Gray;
            LinkButton4.ForeColor = Color.Gray;
            LinkButton5.ForeColor = Color.Gray;

            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            
            string loginId = Session["CustomerLoginId"].ToString();
            
            SqlCommand cmd1 = new SqlCommand("uspGetPayee @loginId", con);
            cmd1.Parameters.AddWithValue("@loginId", loginId);
            ddlAvailablePayees.DataSource = cmd1.ExecuteReader();
            ddlAvailablePayees.DataTextField = "PayeeNickName";
            ddlAvailablePayees.DataBind();

            ddlAvailablePayees.Items.Insert(0, new ListItem("", "0"));
            con.Close();
            con.Open();
            SqlCommand cmd2 = new SqlCommand("uspGetAccountNumbers @loginId", con);
            cmd2.Parameters.AddWithValue("@loginId", loginId);
            ddlSelfAccNo.DataSource = cmd2.ExecuteReader();
            ddlSelfAccNo.DataTextField = "AccountNumber";
            ddlSelfAccNo.DataBind();

            ddlSelfAccNo.Items.Insert(0, new ListItem("", "0"));
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 1;
            LinkButton1.ForeColor = Color.Gray;
            LinkButton2.ForeColor = Color.White;
            LinkButton3.ForeColor = Color.Gray;
            LinkButton4.ForeColor = Color.Gray;
            LinkButton5.ForeColor = Color.Gray;

            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string loginId = Session["CustomerLoginId"].ToString();
            SqlCommand cmd2 = new SqlCommand("uspGetAccountNumbers @loginId", con);
            cmd2.Parameters.AddWithValue("@loginId", loginId);
            ddlBalAccNo.DataSource = cmd2.ExecuteReader();
            ddlBalAccNo.DataTextField = "AccountNumber";
            ddlBalAccNo.DataBind();

            ddlBalAccNo.Items.Insert(0, new ListItem("", "0"));
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 2;
            LinkButton1.ForeColor = Color.Gray;
            LinkButton2.ForeColor = Color.Gray;
            LinkButton3.ForeColor = Color.White;
            LinkButton4.ForeColor = Color.Gray;
            LinkButton5.ForeColor = Color.Gray;

            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            string loginId = Session["CustomerLoginId"].ToString();
            SqlCommand cmd = new SqlCommand("uspGetTransactionDetails @loginId", con);
            cmd.Parameters.AddWithValue("@loginId", loginId);
            gdvTransactions.DataSource = cmd.ExecuteReader();
            gdvTransactions.DataBind();
            con.Close();
            con.Open();
            SqlCommand cmd1 = new SqlCommand("uspGetInwardsTrans @loginId", con);
            cmd1.Parameters.AddWithValue("@loginId", loginId);
            gdvInboundTrans.DataSource = cmd1.ExecuteReader();
            gdvInboundTrans.DataBind();

            con.Close();
        }

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 3;
            LinkButton1.ForeColor = Color.Gray;
            LinkButton2.ForeColor = Color.Gray;
            LinkButton3.ForeColor = Color.Gray;
            LinkButton4.ForeColor = Color.White;
            LinkButton5.ForeColor = Color.Gray;
        }

        protected void btnAddPayee_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            string loginId = Session["CustomerLoginId"].ToString();
            SqlCommand cmd = new SqlCommand("uspInsertPayeeDetails @PayeeName, @CustomerLoginId, @PayeeBank, @PayeeIFScode, @PayeeAddress, @PayeeAccountNumber, @PayeeNickName, @PayeeAccountType",con);
            cmd.Parameters.AddWithValue("@PayeeName", txtPayeeName.Text);
            cmd.Parameters.AddWithValue("@CustomerLoginId", loginId);
            cmd.Parameters.AddWithValue("@PayeeBank", ddlPayeeBank.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@PayeeIFScode", ddlPayeeIFSC.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@PayeeAddress", txtPayeeAddr.Text);
            cmd.Parameters.AddWithValue("@PayeeAccountNumber", txtAccNo.Text);
            cmd.Parameters.AddWithValue("@PayeeNickName", txtPayeeNickName.Text);
            cmd.Parameters.AddWithValue("@PayeeAccountType", rblAccountType.SelectedItem.Text);

            try
            {
                cmd.ExecuteNonQuery();
                litPayeeAddMsg.Text = "<span style='color:green'>Payee added successfully</span>";
                
            }
            catch(Exception)
            {
                litPayeeAddMsg.Text = "<span style='color:red'>Sorry! Payee couldn't be added</span>";
            }
            finally
            {
                con.Close();
            }
        }

        protected void ddlPayeeBank_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetIFSC(ddlPayeeIFSC,ddlPayeeBank);
        }

       


        protected void ddlAccBankName_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetIFSC(ddlAccIFSC, ddlAccBankName);
        }

        public void GetIFSC(DropDownList ddlIFSC, DropDownList ddlBank)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            SqlCommand cmd = new SqlCommand("Select IFScode from tblBankDetails where BankName = @BankName", con);
            cmd.Parameters.AddWithValue("@BankName", ddlBank.SelectedItem.Text);
            try
            {
                ddlIFSC.DataSource = cmd.ExecuteReader();
                ddlIFSC.DataTextField = "IFScode";
                ddlIFSC.DataBind();
                ddlIFSC.Items.Insert(0, new ListItem("", "0"));
            }
            catch (Exception)
            {
                ddlIFSC.Items.Insert(0, new ListItem("No items available", "0"));
            }
            finally
            {
                con.Close();
            }
        }

        
            

        protected void btnAddAccount_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string loginId = Session["CustomerLoginId"].ToString();
            SqlCommand cmd1 = new SqlCommand("uspCheckAccNo @AccNo",con);
            cmd1.Parameters.AddWithValue("@AccNo", txtAccountNumber.Text);
            try
            {
                string acc = cmd1.ExecuteScalar().ToString();
                if (acc.Equals(txtAccountNumber.Text))
                {
                    SqlCommand cmd = new SqlCommand("uspAddAccount @LoginId, @BankName, @BankIFSC, @AccNo", con);
                    cmd.Parameters.AddWithValue("@LoginId", loginId);
                    cmd.Parameters.AddWithValue("@BankName", ddlAccBankName.SelectedItem.Text);
                    cmd.Parameters.AddWithValue("@BankIFSC", ddlAccIFSC.SelectedItem.Text);
                    cmd.Parameters.AddWithValue("@AccNo", txtAccountNumber.Text);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        litAccAddMessage.Text = "<span style='color:green'>Account added successfully</span>";
                    }
                    catch
                    {
                        litAccAddMessage.Text = "<span style='color:red'>This account number is already added</span>";
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            catch (Exception)
            {
                litAccAddMessage.Text = "<span style='color:red'>This Account Number is invalid</span>";
            }
        }

        protected void LinkButton5_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 4;
            LinkButton1.ForeColor = Color.Gray;
            LinkButton2.ForeColor = Color.Gray;
            LinkButton3.ForeColor = Color.Gray;
            LinkButton4.ForeColor = Color.Gray;
            LinkButton5.ForeColor = Color.White;

            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            try
            {
                SqlCommand cmd1 = new SqlCommand("Select BankName from tblBankDetails", con);
                ddlAccBankName.DataSource = cmd1.ExecuteReader();
                ddlAccBankName.DataTextField = "BankName";
                ddlAccBankName.DataBind();
                ddlAccBankName.Items.Insert(0, new ListItem("", "0"));
            }
            catch (Exception)
            {
                ddlAccBankName.Items.Insert(0, new ListItem("No Items Available", "0"));
            }
            finally
            {
                con.Close();
            }
        }

        protected void ddlBalAccNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            
            SqlCommand cmd = new SqlCommand("uspGetBalance @AccNo", con);
            cmd.Parameters.AddWithValue("@AccNo", ddlBalAccNo.SelectedItem.Text);
            try
            {
                lblBalance.Text = "Available Balance: INR " + cmd.ExecuteScalar();
            }
            catch (Exception)
            {
                lblMessage.Text = "Cannot fetch balance";
            }
            finally
            {
                con.Close();
            }           
        }

        protected void ddlSelfAccNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();

            SqlCommand cmd = new SqlCommand("uspGetBalance @AccNo", con);
            cmd.Parameters.AddWithValue("@AccNo", ddlSelfAccNo.SelectedItem.Text);
            try
            {
                lblTranBalance.Text = cmd.ExecuteScalar().ToString();
            }
            catch (Exception)
            {
                lblMessage.Text = "Cannot fetch balance";
            }
            finally
            {
                con.Close();
            }   
        }

        protected void ddlAvailablePayees_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("uspGetPayeeIds @PayeeNickName", con);
            cmd.Parameters.AddWithValue("@PayeeNickName",ddlAvailablePayees.SelectedItem.Text);
            ddlTranPayeeId.DataSource = cmd.ExecuteReader();
            ddlTranPayeeId.DataTextField = "PayeeId";
            ddlTranPayeeId.DataBind();

            ddlTranPayeeId.Items.Insert(0, new ListItem("", "0"));
        }

        protected void ddlTranPayeeId_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("uspGetPayeeAcc @PayeeId", con);
            cmd.Parameters.AddWithValue("@PayeeId", ddlTranPayeeId.SelectedItem.Text);

            lblAccNo.Text = (string)cmd.ExecuteScalar();
            con.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (Convert.ToDecimal(txtAmount.Text) > Convert.ToDecimal(lblTranBalance.Text))
            {
                lblTranMessage.ForeColor = Color.Red;
                lblTranMessage.Text = "Insufficient funds";
            }
            else
            {
                SqlConnection con = new SqlConnection(conStr);
                con.Open();
                string loginId = Session["CustomerLoginId"].ToString();
                SqlCommand cmd1 = new SqlCommand(@"uspAuthenticateCustomer @CustomerLoginId",con);
                cmd1.Parameters.AddWithValue("@CustomerLoginId",loginId);
                try
                {
                    string pass = (string)cmd1.ExecuteScalar();
                    if (txtPassword.Text.Equals(pass))
                    {
                        SqlCommand cmd = new SqlCommand("uspTransact @LoginId,@Amount,@CustAccNo,@PayeeId,@Message out", con);
                        cmd.Parameters.AddWithValue("@LoginId", loginId);
                        cmd.Parameters.AddWithValue("@Amount", txtAmount.Text);
                        cmd.Parameters.AddWithValue("@CustAccNo", ddlSelfAccNo.SelectedItem.Text);
                        cmd.Parameters.AddWithValue("@PayeeId", ddlTranPayeeId.SelectedItem.Text);
                        cmd.Parameters.Add("@Message", SqlDbType.VarChar, 30);
                        cmd.Parameters["@Message"].Direction = ParameterDirection.Output;
                        try
                        {
                            cmd.ExecuteNonQuery();
                            lblTranMessage.Text = cmd.Parameters["@Message"].Value.ToString();
                        }
                        catch (Exception)
                        {
                            lblTranMessage.ForeColor = Color.Red;
                            lblTranMessage.Text = "transaction failed since the payee has not registered the account number";
                        }
                        finally
                        {
                            con.Close();
                            ddlAvailablePayees.SelectedIndex = 0;
                            ddlTranPayeeId.SelectedIndex = 0;
                            ddlSelfAccNo.SelectedIndex = 0;
                            txtAmount.Text = string.Empty;
                            lblTranBalance.Text = string.Empty;
                            lblAccNo.Text = string.Empty;
                        }
                    }
                    else
                    {
                        lblTranMessage.ForeColor = Color.Red;
                        lblTranMessage.Text = "Entered password is not correct";
                    }
                }
                catch(Exception)
                {

                }
            }
        }

        
    }
}