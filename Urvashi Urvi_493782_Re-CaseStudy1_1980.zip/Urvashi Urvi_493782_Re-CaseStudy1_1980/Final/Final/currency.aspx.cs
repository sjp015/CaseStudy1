﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnConvert_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT Rate From CurRate Where FromCur='" + DropDownList1.Text + "' AND ToCur='" + DropDownList2.Text + "'");
        cmd.Connection = con;
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        dr.Read();
        if (dr.HasRows)
        {
            TextBox2.Text = Convert.ToString(Convert.ToDecimal(TextBox1.Text) * Convert.ToDecimal(dr[0]));
        }
        else
        {
            dr.Close();
            SqlCommand cmmd = new SqlCommand("SELECT Rate From CurRate Where FromCur='" + DropDownList2.Text + "' AND ToCur='" + DropDownList1.Text + "'");
            cmmd.Connection = con;
            SqlDataReader drr;
            drr = cmmd.ExecuteReader();
            drr.Read();
            if (drr.HasRows)
            {
                TextBox2.Text = Convert.ToString(Convert.ToDecimal(TextBox1.Text) / Convert.ToDecimal(drr[0]));
            }
        }
    }
}