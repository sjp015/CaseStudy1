﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["FirstName"]==null)
        {
            txtdob.Attributes["max"] = DateTime.Now.ToString("yyyy-MM-dd");
        }
        else
        {
            txtFname.Text = Session["FirstName"].ToString();
            txtLname.Text = Session["Lastname"].ToString();
            txtdob.Text = Session["dob"].ToString();
            txtSName.Text = Session["SName"].ToString();
            txtLocal.Text = Session["Local"].ToString();
            txtState.Text = Session["State"].ToString();
            txtcountry.Text = Session["Country"].ToString();
            txtpsport.Text = Session["Passport"].ToString();
            txtCompName.Text = Session["CompN"].ToString();
            txtAccNo.Text = Session["Acc"].ToString();
            txtContact.Text = Session["Con"].ToString();
            txtEmail.Text = Session["Email"].ToString();
            txtdob.Attributes["max"] = DateTime.Now.ToString("yyyy-MM-dd");
            Session.Abandon();
            Session.RemoveAll();
        }
        RangeValidator1.MaximumValue = DateTime.Now.ToString("yyyy-mm-dd");
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT AccountNumber FROM tblCustomerInBank", con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (dr.HasRows)
                {
                    if (txtAccNo.Text == dr[0].ToString())
                    {
                        Session["FirstName"] = txtFname.Text;
                        Session["Lastname"] = txtLname.Text;
                        Session["dob"] = txtdob.Text;
                        Session["gender"] = rblGender.SelectedValue;
                        Session["SName"] = txtSName.Text;
                        Session["Local"] = txtLocal.Text;
                        Session["State"] = txtState.Text;
                        Session["Country"] = txtcountry.Text;
                        Session["Passport"] = txtpsport.Text;
                        Session["CompN"] = txtCompName.Text;
                        Session["Acc"] = txtAccNo.Text;
                        Session["Con"] = txtContact.Text;
                        Session["Email"] = txtEmail.Text;
                        Response.Redirect("RegisterConfirm.aspx");
                    }
                    else
	                {
                        Label2.Text = "Account Number does not exists";
	                }
                }
            }
        }
    }
}