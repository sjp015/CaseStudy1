CREATE DATABASE RECASE

DROP DATABASE RECASE

create table tblCustomerInBank
(
	CIBId int identity(10001,1) primary key,
	CustomerName varchar(50) not null,
	AccountNumber bigint not null unique,
	AccountType varchar(16) not null,
	BankName varchar(100) not null,
	IFScode varchar(20) not null,
	Branch varchar(50) not null,
	Balance decimal(15,2) not null,
	CustCountry varchar(200) not null,
	Currency varchar(50) not null
)
SELECT AccountNumber FROM tblCustomerInBank
INSERT INTO tblCustomerInBank VALUES ('Chetan Patil',12345714512,'Savings','State Bank of India','SBIN0005621','Bangalore',60000.00,'India','USD (United States Dollars)')
INSERT INTO tblCustomerInBank VALUES ('Peter Varghese',45612784545454,'Savings','Deutsche Bank','DEUB0001521','HongKong',50000.00,'China','USD (United States Dollars)')
INSERT INTO tblCustomerInBank VALUES ('John Doe',4125452121545,'Savings','HSBC Bank','HSBC0000178','Berlin',75000.00,'Europe','USD (United States Dollars)')
INSERT INTO tblCustomerInBank VALUES ('Jane Doe',12578454742213,'Savings','Deutsche Bank Bank','DEUB0001034','Frankfurt',65000.00,'Germany','USD (United States Dollars)')

Select * from tblCustomerInBank
DROP TABLE tblCustomerInBank

create table tblCustomerDetails
(
 UserId varchar(10) Primary Key,
 FirstName varchar(20) not null,
 LastName varchar(20) not null,
 DOB date not null,
 Gender varchar(6) not null,
 StreetName varchar(50) not null,
 Locality varchar(50) not null,
 vState varchar(50) not null,
 Country varchar(50) not null,
 Passport varchar(15) not null,
 CompanyName varchar(50) Not Null,
 AccNo bigint not null REFERENCES tblCustomerInBank(AccountNumber),
 ContactNo bigint not null,
 EmailId varchar(30) not null,
 Pwd varchar(20) not null
)

Create table ConvHistory
(
ConvId int identity(10001,1) primary key,
UserId varchar(10) not null REFERENCES tblCustomerDetails(UserId),
FromAmt decimal(15,2) not null,
FromCur varchar(50) not null,
ToAmt decimal(15,2) not null,
ToCur varchar(50) not null,
ConvDate datetime not null,
)
DROP TABLE ConvHistory
Create table CurrencyRate 
(
FromCur varchar(5) not null,
ToCur varchar(5) not null,
Rate decimal(10,4) not null
)

INSERT INTO CurrencyRate VALUES
('AUD','AUD',1),('AUD','CNY',5.25),('AUD','EUR',0.71),('AUD','GBP',0.61),('AUD','INR',49.84),
('AUD','JPY',84.88),('AUD','MXN',14.30),('AUD','NZD',1.08),('AUD','SGD',1.07),('AUD','USD',0.76),
('CNY','AUD',0.19),('CNY','CNY',1),('CNY','EUR',0.13),('CNY','GBP',0.12),('CNY','INR',9.49),
('CNY','JPY',16.16),('CNY','MXN',2.72),('CNY','NZD',0.21),('CNY','SGD',0.20),('CNY','USD',0.15),
('EUR','AUD',1.42),('EUR','CNY',7.45),('EUR','EUR',1),('EUR','GBP',0.87),('EUR','INR',70.66),
('EUR','JPY',120.33),('EUR','MXN',20.27),('EUR','NZD',1.54),('EUR','SGD',1.51),('EUR','USD',1.08),
('GBP','AUD',1.64),('GBP','CNY',8.49),('GBP','EUR',1.15),('GBP','GBP',1),('GBP','INR',81.53),
('GBP','JPY',138.83),('GBP','MXN',23.39),('GBP','NZD',1.77),('GBP','SGD',1.74),('GBP','USD',1.25),
('INR','AUD',0.02),('INR','CNY',0.11),('INR','EUR',0.014),('INR','GBP',0.012),('INR','INR',1),
('INR','JPY',1.70),('INR','MXN',0.29),('INR','NZD',0.022),('INR','SGD',0.021),('INR','USD',0.015),
('JPY','AUD',0.12),('JPY','CNY',0.062),('JPY','EUR',0.0083),('JPY','GBP',0.0072),('JPY','INR',0.59),
('JPY','JPY',1),('JPY','MXN',0.17),('JPY','NZD',0.013),('JPY','SGD',0.013),('JPY','USD',0.009),
('MXN','AUD',0.07),('MXN','CNY',0.37),('MXN','EUR',0.049),('MXN','GBP',0.043),('MXN','INR',3.49),
('MXN','JPY',5.94),('MXN','MXN',1),('MXN','NZD',0.076),('MXN','SGD',0.075),('MXN','USD',0.053),
('NZD','AUD',0.92),('NZD','CNY',4.84),('NZD','EUR',0.65),('NZD','GBP',0.56),('NZD','INR',45.94),
('NZD','JPY',78.24),('NZD','MXN',13.18),('NZD','NZD',1),('NZD','SGD',0.98),('NZD','USD',0.70),
('SGD','AUD',0.94),('SGD','CNY',4.93),('SGD','EUR',0.66),('SGD','GBP',0.57),('SGD','INR',46.74),
('SGD','JPY',79.60),('SGD','MXN',13.41),('SGD','NZD',1.02),('SGD','SGD',1),('SGD','USD',0.71),
('USD','AUD',1.31),('USD','CNY',6.89),('USD','EUR',0.93),('USD','GBP',0.80),('USD','INR',65.38),
('USD','JPY',111.33),('USD','MXN',18.75),('USD','NZD',1.42),('USD','SGD',1.40),('USD','USD',1)


CREATE TABLE CurRate
(
FromCur varchar(5) not null,
ToCur varchar(5) not null,
Rate decimal(10,4) not null
)
INSERT INTO CurRate VALUES
('AUD','AUD',1),
('CNY','AUD',0.19),('CNY','CNY',1),
('EUR','AUD',1.42),('EUR','CNY',7.45),('EUR','EUR',1),
('GBP','AUD',1.64),('GBP','CNY',8.49),('GBP','EUR',1.15),('GBP','GBP',1),
('INR','AUD',0.02),('INR','CNY',0.11),('INR','EUR',0.014),('INR','GBP',0.012),('INR','INR',1),
('JPY','AUD',0.12),('JPY','CNY',0.062),('JPY','EUR',0.0083),('JPY','GBP',0.0072),('JPY','INR',0.59),
('JPY','JPY',1),
('MXN','AUD',0.07),('MXN','CNY',0.37),('MXN','EUR',0.049),('MXN','GBP',0.043),('MXN','INR',3.49),
('MXN','JPY',5.94),('MXN','MXN',1),
('NZD','AUD',0.92),('NZD','CNY',4.84),('NZD','EUR',0.65),('NZD','GBP',0.56),('NZD','INR',45.94),
('NZD','JPY',78.24),('NZD','MXN',13.18),('NZD','NZD',1),
('SGD','AUD',0.94),('SGD','CNY',4.93),('SGD','EUR',0.66),('SGD','GBP',0.57),('SGD','INR',46.74),
('SGD','JPY',79.60),('SGD','MXN',13.41),('SGD','NZD',1.02),('SGD','SGD',1),
('USD','AUD',1.31),('USD','CNY',6.89),('USD','EUR',0.93),('USD','GBP',0.80),('USD','INR',65.38),
('USD','JPY',111.33),('USD','MXN',18.75),('USD','NZD',1.42),('USD','SGD',1.40),('USD','USD',1)

SELECT * FROM CurRate

DELETE FROM tblCustomerDetails Where UserId='NeGu9352'
DELETE FROM ForgotPwd WHERE UserId='NeGu3208'
SELECT * FROM tblCustomerDetails
SELECT * FROM ForgotPwd
SELECT * FROM tblCustomerInBank
SELECT * FROM ConvHistory
SELECT * FROM CurrencyRate

UPDATE tblCustomerDetails SET FirstName='Nishant',LastName='Gupta',StreetName='Electronic City',Locality='Phase 2',vState='Karnataka',Country='India',ContactNo=7894561251,EmailId='neha@gmail.com' WHERE UserId='NeGu9719'

CREATE TABLE ForgotPwd
(
UserId varchar(10) not null unique REFERENCES tblCustomerDetails(UserId),
Question varchar(100) not null,
Answer varchar(50) not null
)

UPDATE tblCustomerDetails SET Locality='HongKong' WHERE UserId='PeVa8928'
SELECT * FROM tblCustomerDetails
SELECT * FROM CurRate



