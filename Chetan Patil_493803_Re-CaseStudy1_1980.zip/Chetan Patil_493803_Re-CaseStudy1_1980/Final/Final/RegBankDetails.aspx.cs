﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class RegBankDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] == null)
        {
            Response.Redirect("home.aspx");
        }
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        SqlConnection conn = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT AccNo From tblCustomerDetails WHERE UserId='" + Session["uid"].ToString() + "'", con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        dr.Read();
        if (dr.HasRows)
        {
            conn.Open();
            SqlCommand cmmd = new SqlCommand("SELECT * FROM tblCustomerInBank WHERE AccountNumber=" + dr[0].ToString(), conn);
            SqlDataReader drr;
            drr = cmmd.ExecuteReader();
            drr.Read();
            if (drr.HasRows)
            {
                txtName.Text = drr[1].ToString();
                txtAcc.Text = drr[2].ToString();
                txtType.Text = drr[3].ToString();
                txtBName.Text = drr[4].ToString();
                txtIFScode.Text = drr[5].ToString();
                txtBranch.Text = drr[6].ToString();
                txtBalance.Text = drr[7].ToString();
                txtcur.Text = drr[9].ToString();
            }
        }
    }
}