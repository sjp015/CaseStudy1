﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
public partial class RegChangePwd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"]==null)
        {
            Response.Redirect("home.aspx");
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        SqlConnection conn = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT Pwd From tblCustomerDetails WHERE UserId='"+Session["uid"].ToString()+"'", con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        dr.Read();
        if (dr.HasRows)
        {
            if (dr[0].ToString() == txtold.Text)
            {
                    conn.Open();
                    SqlCommand cmmd = new SqlCommand("UPDATE tblCustomerDetails SET Pwd='" + txtnewrep.Text + "' WHERE USerId='" + Session["uid"].ToString() + "'", conn);
                    int i = cmmd.ExecuteNonQuery();
                    if (i != 0)
                    {
                        MessageBox.Show("Password changed successfully");
                        Response.Redirect("RegChangePwd.aspx");
                    }
            }
            else
            {
                Label1.Text = "Old password is invalid!";
            }
        }
    }
}