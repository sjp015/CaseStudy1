﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class RegisterQuestion : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session == null)
        {
            Response.Redirect("home.aspx");
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        SqlCommand cmdd = new SqlCommand("INSERT INTO ForgotPwd VALUES(@uid,@Q,@A)", con);
        cmdd.Parameters.AddWithValue("@uid", Session["uid"].ToString());
        cmdd.Parameters.AddWithValue("@Q", DropDownList1.Text);
        cmdd.Parameters.AddWithValue("@A", txtAns.Text);
        cmdd.ExecuteNonQuery();
        Response.Redirect("RegisterSuccess.aspx");
    }
}