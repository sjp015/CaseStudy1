﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
public partial class ForgotPwd : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
    static string loginid = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT Question from ForgotPwd Where UserId='"+ txtuid.Text +"'",con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        dr.Read();
        if(dr.HasRows)
        {
            loginid = txtuid.Text;
            TextBox3.Text = dr[0].ToString();
            dr.Close();
            MultiView1.ActiveViewIndex = 1;
        }
        else
        {
            Label1.Text = "User Id does not exist";
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlCommand cmmd = new SqlCommand("SELECT Answer from ForgotPwd Where UserId='" + loginid + "'",con);
        con.Open();
        SqlDataReader drr;
        drr = cmmd.ExecuteReader();
        drr.Read();
        if (drr.HasRows)
        {
            if (TextBox4.Text==drr[0].ToString())
            {
                MultiView1.ActiveViewIndex = 2;
            }
            else
            {
                MultiView1.ActiveViewIndex = 1;
                Label2.Text = "Wrong Answer! Try Again";
            }
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("UPDATE tblCustomerDetails SET Pwd='"+ txtnew.Text+"' WHERE UserId='" + loginid + "'",con);
        cmd.ExecuteNonQuery();
        MessageBox.Show("Your password has been changed successfully");
        Response.Redirect("Login.aspx");
    }
}