﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Default4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session == null)
        {
            Response.Redirect("home.aspx");
        }
        if (!IsPostBack)
        {
            txtFname.Text = Session["FirstName"].ToString();
            txtLname.Text = Session["Lastname"].ToString();
            txtdob.Text = Session["dob"].ToString();
            txtGnd.Text = Session["gender"].ToString();
            txtSName.Text = Session["SName"].ToString();
            txtLocal.Text = Session["Local"].ToString();
            txtState.Text = Session["State"].ToString();
            txtcountry.Text = Session["Country"].ToString();
            txtpsport.Text = Session["Passport"].ToString();
            txtCompName.Text = Session["CompN"].ToString();
            txtAccNo.Text = Session["Acc"].ToString();
            txtContact.Text = Session["Con"].ToString();
            txtEmail.Text = Session["Email"].ToString();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Session["FirstName"] = txtFname.Text;
        Session["Lastname"] = txtLname.Text;
        Session["dob"] = txtdob.Text;
        Session["gender"] = txtGnd.Text;
        Session["SName"] = txtSName.Text;
        Session["Local"] = txtLocal.Text;
        Session["State"] = txtState.Text;
        Session["Country"] = txtcountry.Text;
        Session["Passport"] = txtpsport.Text;
        Session["CompN"] = txtCompName.Text;
        Session["Acc"] = txtAccNo.Text;
        Session["Con"] = txtContact.Text;
        Session["Email"] = txtEmail.Text;

        Random rand = new Random();
        string uid = Session["FirstName"].ToString().Substring(0, 2) + Session["LastName"].ToString().Substring(0, 2) + rand.Next(1000, 9999).ToString();
        string pwd = System.Web.Security.Membership.GeneratePassword(8, 0);

        SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        SqlCommand cmd = new SqlCommand("INSERT INTO tblCustomerDetails VALUES(@id,@FName,@LName,@dob,@Gender,@SName,@Local,@State,@country,@pasp,@Comp,@Acc,@Con,@mail,@pwd)", con);
        cmd.Parameters.AddWithValue("@id", uid);
        cmd.Parameters.AddWithValue("@FName", Session["FirstName"].ToString());
        cmd.Parameters.AddWithValue("@LName", Session["Lastname"].ToString());
        cmd.Parameters.AddWithValue("@dob", Session["dob"].ToString());
        cmd.Parameters.AddWithValue("@Gender", Session["gender"].ToString());
        cmd.Parameters.AddWithValue("@SName", Session["SName"].ToString());
        cmd.Parameters.AddWithValue("@Local", Session["Local"].ToString());
        cmd.Parameters.AddWithValue("@State", Session["State"].ToString());
        cmd.Parameters.AddWithValue("@country", Session["Country"].ToString());
        cmd.Parameters.AddWithValue("@pasp", Session["Passport"].ToString());
        cmd.Parameters.AddWithValue("@Comp", Session["CompN"].ToString());
        cmd.Parameters.AddWithValue("@Acc", Session["Acc"].ToString());
        cmd.Parameters.AddWithValue("@Con", Session["Con"].ToString());
        cmd.Parameters.AddWithValue("@mail", Session["Email"].ToString());
        cmd.Parameters.AddWithValue("@pwd", pwd);
        cmd.ExecuteNonQuery();

        Session["uid"] = uid;
        Session["pwd"] = pwd;
        Response.Redirect("RegisterQuestion.aspx");
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Session["FirstName"] = txtFname.Text;
        Session["Lastname"] = txtLname.Text;
        Session["dob"] = txtdob.Text;
        Session["gender"] = txtGnd.Text;
        Session["SName"] = txtSName.Text;
        Session["Local"] = txtLocal.Text;
        Session["State"] = txtState.Text;
        Session["Country"] = txtcountry.Text;
        Session["Passport"] = txtpsport.Text;
        Session["CompN"] = txtCompName.Text;
        Session["Acc"] = txtAccNo.Text;
        Session["Con"] = txtContact.Text;
        Session["Email"] = txtEmail.Text;
        Response.Redirect("Register.aspx");
    }
}