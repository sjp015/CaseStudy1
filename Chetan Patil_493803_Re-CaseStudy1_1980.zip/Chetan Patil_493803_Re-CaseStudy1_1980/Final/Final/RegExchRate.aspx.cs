﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class RegExchRate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"]==null)
        {
            Response.Redirect("home.aspx");
        }
    }

    protected void btnConvert_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT Rate From CurrencyRate Where FromCur='" + DropDownList1.Text + "' AND ToCur='" + DropDownList2.Text + "'");
        cmd.Connection = con;
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        dr.Read();
        if (dr.HasRows)
        {
            TextBox2.Text = Convert.ToString(Convert.ToDecimal(TextBox1.Text) * Convert.ToDecimal(dr[0]));
        }
    }
}