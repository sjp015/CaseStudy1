﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

public partial class Logina : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void btnup_Click(object sender, EventArgs e)
    {
        Response.Redirect("Register.aspx");
    }
    protected void btnin_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT FirstName FROM tblCustomerDetails WHERE UserId='" + TextBox1.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND Pwd='" + TextBox2.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        dr.Read();
        if (dr.HasRows)
        {
            Session["uid"]=TextBox1.Text;
            Session["FirstName"] = dr[0].ToString();
            Response.Redirect("RegDashboard.aspx");
        }
        else
        {
            MessageBox.Show("Invalid UserId or Password");
        }
    }
}