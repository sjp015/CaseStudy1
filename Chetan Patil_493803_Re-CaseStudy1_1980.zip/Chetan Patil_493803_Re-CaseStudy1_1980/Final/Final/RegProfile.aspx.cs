﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
public partial class RegProfile : System.Web.UI.Page
{
    public static string SNAME;
    public static string LNAME;
    public static string STATE;
    public static string COUNTRY;
    public static string EMAIL;
    public static string CONTACT;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] == null)
        {
            Response.Redirect("home.aspx");
        }
        if (!Page.IsPostBack)
        {
            btnupd.Enabled = false;
            SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * FROM tblCustomerDetails WHERE UserId='" + Session["uid"].ToString() + "'", con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                txtFname.Text = dr[1].ToString();
                txtLname.Text = dr[2].ToString();
                txtdob.Text = ((DateTime)dr[3]).ToString("d");
                txtGnd.Text = dr[4].ToString();
                SNAME = dr[5].ToString();
                txtSName.Text = dr[5].ToString();
                LNAME = dr[6].ToString();
                txtLocal.Text = dr[6].ToString();
                STATE = dr[7].ToString();
                txtState.Text = dr[7].ToString();
                COUNTRY = dr[8].ToString();
                txtcountry.Text = dr[8].ToString();
                CONTACT = dr[12].ToString();
                txtContact.Text = dr[12].ToString();
                EMAIL = dr[13].ToString();
                txtEmail.Text = dr[13].ToString();
            }
            dr.Close();
            con.Close();
        }
    }
    protected void btnedit_Click(object sender, EventArgs e)
    {
        btnedit.Enabled = false;
        btnupd.Enabled = true;
        txtContact.ReadOnly = false;
        txtcountry.ReadOnly = false;
        txtEmail.ReadOnly = false;
        txtLocal.ReadOnly = false;
        txtSName.ReadOnly = false;
        txtState.ReadOnly = false;

    }
    protected void btnupd_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        conn.Open();
        SqlCommand comd = new SqlCommand("UPDATE tblCustomerDetails SET StreetName='" + SNAME + "',Locality='" + LNAME + "',vState='" + STATE + "',Country='" + COUNTRY + "',ContactNo=" + CONTACT + ",EmailId='" + EMAIL + "' WHERE UserId='" + Session["uid"].ToString() + "'", conn);
        comd.ExecuteNonQuery();
        int i = comd.ExecuteNonQuery();
        if (i > 0)
        {
            btnedit.Enabled = true;
            btnupd.Enabled = false;
            txtContact.ReadOnly = true;
            txtcountry.ReadOnly = true;
            txtdob.ReadOnly = true;
            txtEmail.ReadOnly = true;
            txtFname.ReadOnly = true;
            txtGnd.ReadOnly = true;
            txtLname.ReadOnly = true;
            txtLocal.ReadOnly = true;
            txtSName.ReadOnly = true;
            txtState.ReadOnly = true;
            Response.Redirect("RegProfile.aspx");
        }
    }

    protected void txtSName_TextChanged(object sender, EventArgs e)
    {
        SNAME = txtSName.Text;
    }
    protected void txtLocal_TextChanged(object sender, EventArgs e)
    {
        LNAME = txtLocal.Text;
    }
    protected void txtState_TextChanged(object sender, EventArgs e)
    {
        STATE = txtState.Text;
    }
    protected void txtcountry_TextChanged(object sender, EventArgs e)
    {
        COUNTRY = txtcountry.Text;
    }
    protected void txtContact_TextChanged(object sender, EventArgs e)
    {
        CONTACT = txtContact.Text;
    }
    protected void txtEmail_TextChanged(object sender, EventArgs e)
    {
        EMAIL = txtEmail.Text;
    }
}