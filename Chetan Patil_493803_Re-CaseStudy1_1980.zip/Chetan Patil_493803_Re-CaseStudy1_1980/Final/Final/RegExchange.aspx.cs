﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

public partial class RegExchange : System.Web.UI.Page
{
    public static string acc;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"]==null)
        {
            Response.Redirect("home.aspx");
        }
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        SqlConnection conn = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT AccNo From tblCustomerDetails WHERE UserId='" + Session["uid"].ToString() + "'", con);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        dr.Read();
        if (dr.HasRows)
        {
            acc = dr[0].ToString();
            conn.Open();
            SqlCommand cmmd = new SqlCommand("SELECT Balance,Currency FROM tblCustomerInBank WHERE AccountNumber=" + dr[0].ToString(), conn);
            SqlDataReader drr;
            drr = cmmd.ExecuteReader();
            drr.Read();
            if (drr.HasRows)
            {
                txtAmt.Text = drr[0].ToString();
                txtCur.Text = drr[1].ToString();
                drr.Close();
                dr.Close();
            }
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        SqlConnection conn = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        SqlConnection connection = new SqlConnection(@"Server=INBASDPC12411\SQLEXPRESS;Database=RECASE;Integrated Security=false;uid=sa;pwd=System123");
        con.Open();
        string fcur = txtCur.Text.Substring(0, 3);
        string tcur = ToCurList.Text.Substring(0, 3);
        SqlCommand cmd = new SqlCommand("SELECT Rate From CurRate Where FromCur='" + fcur + "' AND ToCur='" + tcur + "'");
        cmd.Connection = con;
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        dr.Read();
        if (dr.HasRows)
        {
            string amt = Convert.ToString(Convert.ToDecimal(txtAmt.Text) * Convert.ToDecimal(dr[0]));
            conn.Open();
            SqlCommand cmmd = new SqlCommand("UPDATE tblCustomerInBank SET Balance=" + amt + ",Currency='" + ToCurList.Text + "' WHERE AccountNumber =" + acc, conn);
            cmmd.ExecuteNonQuery();
            MessageBox.Show("Exchange Successfull!!\n");
            SqlCommand comd = new SqlCommand("INSERT INTO ConvHistory VALUES (@id,@Famt,@Fcur,@Tamt,@Tcur,@date)", conn);
            comd.Parameters.AddWithValue("@id", Session["uid"]);
            comd.Parameters.AddWithValue("@Famt",txtAmt.Text);
            comd.Parameters.AddWithValue("@Fcur", txtCur.Text);
            comd.Parameters.AddWithValue("@Tamt", amt);
            comd.Parameters.AddWithValue("@Tcur", ToCurList.Text);
            DateTime date = DateTime.Now;
            comd.Parameters.AddWithValue("@date", date.ToString());
            comd.ExecuteNonQuery();
            Response.Redirect("RegExchange.aspx");
        }
        else
        {
            SqlCommand cmmdrate = new SqlCommand("SELECT Rate From CurRate Where FromCur='" + tcur + "' AND ToCur='" + fcur + "'");
            connection.Open();
            cmmdrate.Connection = connection;
            SqlDataReader drr;
            drr = cmmdrate.ExecuteReader();
            drr.Read();
            if (drr.HasRows)
            {
                dr.Close();
                string amt = Convert.ToString(Convert.ToDecimal(txtAmt.Text) / Convert.ToDecimal(drr[0]));
                conn.Open();
                SqlCommand command = new SqlCommand("UPDATE tblCustomerInBank SET Balance=" + amt + ",Currency='" + ToCurList.Text + "' WHERE AccountNumber =" + acc, conn);
                command.ExecuteNonQuery();
                MessageBox.Show("Exchange Successfull!!\n");
                SqlCommand comd = new SqlCommand("INSERT INTO ConvHistory VALUES (@id,@Famt,@Fcur,@Tamt,@Tcur,@date)", conn);
                comd.Parameters.AddWithValue("@id", Session["uid"]);
                comd.Parameters.AddWithValue("@Famt", txtAmt.Text);
                comd.Parameters.AddWithValue("@Fcur", txtCur.Text);
                comd.Parameters.AddWithValue("@Tamt", amt);
                comd.Parameters.AddWithValue("@Tcur", ToCurList.Text);
                DateTime date = DateTime.Now;
                comd.Parameters.AddWithValue("@date", date.ToString());
                comd.ExecuteNonQuery();
                Response.Redirect("RegExchange.aspx");
            }
        }
    }
}